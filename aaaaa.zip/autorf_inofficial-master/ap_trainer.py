import os

# pytorch-lightning
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import ModelCheckpoint, RichProgressBar
from pytorch_lightning.plugins import DDPPlugin
import warnings

# config
from argconf import argconf_parse


def resolve_ckpt(run_path, ckpt_path):
    if ckpt_path is None:
        return None
    if ckpt_path in ['last', 'latest']: 
        # load based on run_path
        res_ckpt_path  = f"{run_path}/last.ckpt"
        if not os.path.exists(res_ckpt_path):
            print("CHECKPOINT DOES NOT EXIST - STARTING FROM SCRATCH")
            res_ckpt_path = None
    elif "/" not in ckpt_path:
        res_ckpt_path = f"{run_path}/{ckpt_path}"
    else:
        # full path
        res_ckpt_path = os.path.expanduser(ckpt_path)
    return res_ckpt_path
        
    
    

def create_trainer(hparams=None):
    if hparams is None:
        hparams = argconf_parse()

    warnings.filterwarnings("ignore", category=DeprecationWarning)
    # final exp_name
    run_conf = hparams.run
    run_conf.store_root = os.path.expanduser(run_conf.store_root)
    if run_conf.exp_name is None:
        run_conf.exp_name = hparams.conf.split("/")[-1].split(".")[0]
    if run_conf.get("overfit", False):
        run_conf.exp_name = f"overfit_{run_conf.exp_name}"

    os.makedirs(f"{run_conf.store_root}/ckpts/{run_conf.project}/{run_conf.exp_name}", exist_ok=True)
    os.makedirs(f"{run_conf.store_root}/logs/{run_conf.project}/{run_conf.exp_name}", exist_ok=True)
    if run_conf.get("store_local", False):
        result_root = f"{run_conf.store_root}/results/{run_conf.project}/{run_conf.exp_name}"
        os.makedirs(result_root, exist_ok=True)
        run_conf.result_root = result_root
        print(f"+++ Result root: {result_root} +++")

    # resolve ckpt_path
    hparams.run.ckpt_path = resolve_ckpt(f"{run_conf.store_root}/ckpts/{run_conf.project}/{run_conf.exp_name}", run_conf.ckpt_path)

    # logging
    try:
        pbar = RichProgressBar(refresh_rate=run_conf.get("print_every_n", 1))
    except:
        pbar = RichProgressBar(refresh_rate_per_second=run_conf.get("print_every_n", 1))

    callbacks = [pbar]

    # model checkpoint logic
    ckpt_stragety = run_conf.get("ckpt_stragety", "last_0")
    if ckpt_stragety is None:
        pass
    else:
        ckpt_mode = ckpt_stragety.split("_")[0]
        save_top_k = int(ckpt_stragety.split("_")[1])

        if ckpt_mode == "last":
            if save_top_k < 1:
                ckpt_cb = ModelCheckpoint(
                    dirpath=f"{run_conf.store_root}/ckpts/{run_conf.project}/{run_conf.exp_name}",
                    filename="{epoch:d}",
                    save_last=True,
                )
            else:
                ckpt_cb = ModelCheckpoint(
                    dirpath=f"{run_conf.store_root}/ckpts/{run_conf.project}/{run_conf.exp_name}",
                    filename="{epoch:d}",
                    monitor="global_step",
                    save_top_k=save_top_k,
                )
        else:
            ckpt_cb = ModelCheckpoint(
                dirpath=f"{run_conf.store_root}/ckpts/{run_conf.project}/{run_conf.exp_name}",
                filename="{epoch:d}",
                monitor=run_conf.ckpt_monitor,
                mode=ckpt_mode,
                save_top_k=save_top_k,
            )
        callbacks.append(ckpt_cb)

    logger = None
    if run_conf.logger == "wandb":
        from pytorch_lightning.loggers import WandbLogger

        logger = WandbLogger(
            project=run_conf.project,
            name=run_conf.exp_name,
            save_dir=f"{run_conf.store_root}/logs/{run_conf.project}",
            offline=run_conf.get("log_offline", False),
            log_model=False,
        )
        setattr(logger, "type", "wandb")
    elif run_conf.logger == "tensorboard":
        from pytorch_lightning.loggers import TensorBoardLogger

        logger = TensorBoardLogger(
            save_dir=f"{run_conf.store_root}/logs/{run_conf.project}", name=run_conf.exp_name, default_hp_metric=False
        )
        setattr(logger, "type", "tensorboard")
        logger.experiment.add_text("config_name", hparams.conf)

    trainer = Trainer(
        max_epochs=run_conf.get("num_epochs", -1),
        callbacks=callbacks,
        logger=logger,
        enable_model_summary=False,
        enable_checkpointing=True,
        accelerator="auto",
        devices=run_conf.get("num_gpus", 1),
        num_sanity_val_steps=run_conf.get("num_sanity_val_steps", 1),
        benchmark=run_conf.get("benchmark", False),
        profiler="simple" if run_conf.get("num_gpus", 1) == 1 else None,
        strategy=DDPPlugin(find_unused_parameters=True) if run_conf.get("num_gpus", 1) > 1 else None,
        fast_dev_run=run_conf.get("fast_dev_run", False),
        limit_train_batches=run_conf.get("limit_train_batches", 1.0),
        precision=run_conf.get("precision", 32),
        check_val_every_n_epoch=run_conf.get("check_val_every_n_epoch", 1),
    )

    return trainer, hparams


def create_dataset(hparams, split="train"):
    import datasets

    # assert
    data_conf = hparams.data
    dataset_cls = getattr(datasets, data_conf.dataset_name)
    data_conf.root_dir = os.path.expanduser(data_conf.root_dir)
    dataset = dataset_cls(root_dir=data_conf.root_dir, split=split, data_conf=data_conf)
    return dataset


def create_dataloader(hparams, split="train", collate_fn=None):
    from torch.utils.data import DataLoader

    train_conf = hparams.train
    dataset = create_dataset(hparams, split)
    return DataLoader(
        dataset=dataset,
        batch_size=train_conf.get(f"batch_size_{split}", train_conf.batch_size),
        shuffle=train_conf.get(f"shuffle_{split}", train_conf.get("shuffle", True)),
        num_workers=train_conf.get(f"num_workers_{split}", train_conf.get("num_workers", 4)),
        pin_memory=train_conf.get("pin_memory", True),
        collate_fn=collate_fn
    )


if __name__ == "__main__":
    hparams = argconf_parse()
    trainer, hparams = create_trainer(hparams)

    train_dataloader = create_dataloader(hparams, "train")
    val_dataloader = create_dataloader(hparams, "val")


