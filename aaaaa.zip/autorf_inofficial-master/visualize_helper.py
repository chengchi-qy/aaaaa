
import trimesh
import numpy as np
import torch

import os
import imageio

from dutils import bbox2bbox_corners, dot
from PIL import Image


def project_3d_2d(cam2world, K, world_point, with_z=False, discrete=True):
    from dutils import dot

    if isinstance(world_point, np.ndarray):
        cam_point = dot(np.linalg.inv(cam2world), world_point)
        img_point = dot(K, cam_point)
        uv_point = img_point[:, :2] / img_point[:, 2][:, None]
        if discrete:
            uv_point = np.round(uv_point).astype(int)
        if with_z:
            return uv_point, img_point[:, 2]
        return uv_point

    else:
        cam_point = dot(torch.inverse(cam2world), world_point)
        img_point = dot(K, cam_point)
        uv_point = img_point[:, :2] / img_point[:, 2][:, None]
        if discrete:
            uv_point = torch.round(uv_point).int()
        if with_z:
            return uv_point, img_point[:, 2]

        return uv_point


def overlay(bg_img, fg_img, start, mode="hard", extend=False):
    end = start + fg_img.shape[:2]
    if extend is False:
        crop_start = np.array([min(max(start[0], 0), bg_img.shape[0]), min(
            max(start[1], 0), bg_img.shape[1])])
        rel_start = crop_start - start
        crop_end = np.array([min(end[0], bg_img.shape[0]),
                            min(end[1], bg_img.shape[1])])
        rel_end = crop_end - crop_start + rel_start
        if (rel_end[0] - rel_start[0]) > 0 and (rel_end[1] - rel_start[1] > 0):
            if mode == "hard":
                bg_img[crop_start[0]: crop_end[0], crop_start[1]: crop_end[1]] = fg_img[
                    rel_start[0]: rel_end[0], rel_start[1]: rel_end[1]
                ]
            else:
                if fg_img.max() > 1:
                    fg_img = fg_img / 255
                a0 = bg_img[crop_start[0]: crop_end[0], crop_start[1]: crop_end[1], 3] + fg_img[
                    rel_start[0]: rel_end[0], rel_start[1]: rel_end[1], 3
                ] * (1 - bg_img[crop_start[0]: crop_end[0], crop_start[1]: crop_end[1], 3])
                bg_img[crop_start[0]: crop_end[0], crop_start[1]: crop_end[1], :3] = (
                    bg_img[crop_start[0]: crop_end[0],
                           crop_start[1]: crop_end[1], :3]
                    * bg_img[crop_start[0]: crop_end[0], crop_start[1]: crop_end[1], 3:4]
                    + fg_img[rel_start[0]: rel_end[0],
                             rel_start[1]: rel_end[1], :3]
                    * fg_img[rel_start[0]: rel_end[0], rel_start[1]: rel_end[1], 3:4]
                    * (1 - bg_img[crop_start[0]: crop_end[0], crop_start[1]: crop_end[1], 3:4])
                ) / (0.0001 + a0[..., None])
                bg_img[crop_start[0]: crop_end[0],
                       crop_start[1]: crop_end[1], 3] = a0


def unit_amodalize(cam2can, intrinsics, max_W=300, max_H=300):
    unit_bbox = 0.52 * np.array([-1, -1, -1, 1, 1, 1])
    unit_corners = torch.from_numpy(bbox2bbox_corners(unit_bbox)).float()
    # does it need obj2can???
    corners_2d = project_3d_2d(cam2can, intrinsics, unit_corners)
    amodal_bbox = torch.cat(
        [torch.min(corners_2d, 0).values, torch.max(corners_2d, 0).values])
    amodal_W = amodal_bbox[2] - amodal_bbox[0]
    amodal_H = amodal_bbox[3] - amodal_bbox[1]

    scale_x = min(1, max_W/amodal_W)
    scale_y = min(1, max_H/amodal_H)

    amodal_intrinsics = torch.clone(intrinsics)
    amodal_intrinsics[:2, 2] = intrinsics[..., :2, 2] - \
        amodal_bbox[:2].to(intrinsics)
    amodal_intrinsics = torch.from_numpy(
        np.diag([scale_x, scale_y, 1])).to(intrinsics) @ amodal_intrinsics
    amodal_W = int(scale_x * amodal_W)
    amodal_H = int(scale_y * amodal_H)
    return amodal_intrinsics, amodal_H, amodal_W


def base_render_track(autoRF, camera_track, color_code, density_code, cam2can, intrinsics, base_K, base_H, base_W):
    base_overlay_imgs = []
    instance_imgs = []
    z_imgs = []
    for camN2cam in camera_track:
        camN2can = cam2can@torch.from_numpy(camN2cam).float().to(autoRF.device)
        amodal_intrinsics, amodal_H, amodal_W = unit_amodalize(
            camN2can, intrinsics)
        rend_img = autoRF.full_render(
            color_code, density_code, amodal_H, amodal_W, amodal_intrinsics, camN2can, alpha_th=None)
        # vis.image(rend_img.transpose(2, 0, 1), opts=dict(store_history=True), win=f"tracko_{sample_idx}")
        base_overlay_img = np.zeros((base_H, base_W, 4), np.float32)
        final_K = amodal_intrinsics.cpu().numpy()
        scale_x, scale_y = base_K[0, 0] / \
            final_K[0, 0], base_K[1, 1] / final_K[1, 1]
        if scale_x > 10 or scale_y > 10:
            print("SPECIAL INTRINSICS")
            base_overlay_imgs.append(base_overlay_img)
            instance_imgs.append(rend_img)
            z_buf_base = 1000 * np.ones((base_H, base_W))
            z_imgs.append(z_buf_base)
            continue
        # rgb_img = Image.fromarray(rgb_rend)
        rgb_img = Image.fromarray((rend_img * 255).astype(np.uint8))
        # resize to base
        b_scaled_H, b_scaled_W = int(
            amodal_H * scale_y), int(amodal_W * scale_x)
        base_rgb_img = rgb_img.resize((b_scaled_W, b_scaled_H))

        base_start = np.array(base_K[[1, 0], 2] - [final_K[1, 2] * scale_y, final_K[0, 2] * scale_x]).astype(
            int
        )
        overlay(base_overlay_img, np.array(base_rgb_img),
                base_start, mode='hard', extend=False)
        base_overlay_imgs.append(base_overlay_img)
        instance_imgs.append(rend_img)
        # depth map  ->>>
        box = trimesh.primitives.Box()
        box.apply_transform(torch.inverse(cam2can).cpu().numpy())
        # compute z buffer
        uv_points = np.stack(np.meshgrid(
            np.arange(base_H), np.arange(base_W)), -1) + base_start
        uvd_points = np.concatenate(
            [uv_points, np.ones((*uv_points.shape[:2], 1))], -1)

        cam_origin = np.zeros_like(uvd_points).reshape(-1, 3)
        cam_origin = dot(camN2cam, cam_origin)  # in camS space
        cam_vecs = dot(np.linalg.inv(base_K),
                       uvd_points.reshape(-1, 3)[:, [1, 0, 2]])
        cam_vecs = dot(camN2cam, cam_vecs)  # in cam S space
        cam_vecs -= cam_origin  # only direction
        cam_vecs /= np.linalg.norm(cam_vecs, axis=1)[:, None]
        # transform to camera track space
        # box ray intersection
        intersec_data = box.ray.intersects_location(cam_origin, cam_vecs)
        intersec_points = intersec_data[0]  # in cam0 coords
        # in current camera frame
        intersec_pointsS = dot(np.linalg.inv(camN2cam), intersec_points)

        # intersec_data[0][..., 2]
        z_vals = np.linalg.norm(intersec_pointsS, axis=1)
        ray_z = np.stack([intersec_data[1], z_vals], 1)
        ray_z = ray_z[np.argsort(ray_z[:, 1])]

        first_hit_ray_z = ray_z[np.unique(ray_z[:, 0], return_index=True)[
            1]]  # ray index, z dist
        z_buf = 1000 * np.ones((base_W, base_H))  # rays are in W,H ordering
        z_buf.reshape(-1)[first_hit_ray_z[:, 0].astype(int)
                          ] = first_hit_ray_z[:, 1]
        z_buf = z_buf.transpose(1, 0)
        z_buf_base = 1000 * np.ones((base_H, base_W))
        overlay(z_buf_base, z_buf, base_start)
        z_imgs.append(z_buf_base)
        # <<<-

    return base_overlay_imgs, instance_imgs, z_imgs


def full_render_entities_framewise(autoRF, track_idx, render_entities, camera_track, base_H, base_W, base_factor, grid_out_path=None, overlay_mode='hard', overlay_th=0.7, white_bg=False, org_K=None):
    # compute track_data
    base_K = np.diag([base_factor, base_factor, 1]) @ org_K
    from PIL import Image

    track_inst_imgs = {}

    for r_ent in render_entities:
        base_overlay_imgs, inst_imgs, z_imgs = base_render_track(
            autoRF, camera_track[track_idx:track_idx+1], r_ent['color_code'], r_ent['density_code'], r_ent['cam2can'], r_ent['intrinsics'], base_K, base_H, base_W)
        track_inst_imgs[r_ent['inst_token']] = {
            'base_imgs': base_overlay_imgs,
            "inst_imgs": inst_imgs,
            "z_imgs": z_imgs
        }

    overlayed_imgs = []
    overlay_stack = np.stack([x['base_imgs'][0]
                             for x in track_inst_imgs.values()])
    z_stack = np.stack([x['z_imgs'][0] for x in track_inst_imgs.values()])
    N, H, W, C = overlay_stack.shape
    # inverse order
    z_order = np.argsort(-z_stack.transpose(1, 2, 0).reshape(-1, N), axis=1)
    # get per pixel z buffer ordering

    per_pix_ordered = [
        overlay_stack.transpose(1, 2, 0, 3)
        .reshape(-1, N, C)[tuple(np.stack([np.arange(len(z_order)), z_order[:, i]], 1).T)]
        .reshape(H, W, C)
        for i in range(N)
    ]
    # for each color channel, order stack by z buf
    if grid_out_path is not None:
        grid_img_fn = f"{grid_out_path}/{track_idx}.png"
        bg_img = np.array(Image.open(grid_img_fn))/255
        overlay_mode = 'hard_th'  # to not see grid through alpha mask
    else:
        if white_bg:
            bg_img = np.ones_like(overlay_stack[0], dtype=np.float32)
        else:
            bg_img = np.zeros_like(overlay_stack[0], dtype=np.float32)
    if overlay_mode == "hard_th":
        for frame in per_pix_ordered:
            if frame.max() > 1:
                frame = frame / 255
            new_alpha = np.clip(
                1 / (1 + np.exp(-(frame[..., 3] - overlay_th) * 50)), 0, 1)
            new_frame = np.concatenate(
                [frame[..., :3], new_alpha[..., None]], -1)
            bg_img[frame[..., 3] >
                   overlay_th] = new_frame[frame[..., 3] > overlay_th]
    if overlay_mode == 'hard':
        for frame in per_pix_ordered:
            if frame.max() > 1:
                frame = frame / 255
            bg_img[frame[..., 3] > overlay_th] = frame[frame[..., 3] > overlay_th]
    else:
        for frame in per_pix_ordered[::-1]:
            if frame.max() > 1:
                frame = frame / 255
            a0 = bg_img[..., 3] + frame[..., 3] * (1 - bg_img[..., 3])
            bg_img[..., :3] = (
                bg_img[..., :3] * bg_img[..., 3:4] + frame[..., :3] *
                frame[..., 3:4] * (1 - bg_img[..., 3:4])
            ) / (0.0001 + a0[..., None])
            bg_img[..., 3] = a0
    overlayed_imgs.append(bg_img)
    return overlayed_imgs, track_inst_imgs


def convert_RGBA_to_RGB(img):
    return np.tile((1 - img[..., 3])[..., None], (1, 1, 3)) + img[..., 3][..., None] * img[..., :3]


def store_renderings_framewise(store_root, frame_token, track_idx, overlayed_imgs, track_inst_imgs):
    # store renderings
    store_path = f"{store_root}/{frame_token}"
    os.makedirs(store_path, exist_ok=True)
    overlays_rgba_root = f"{store_path}/overlays_rgba/"
    overlays_root = f"{store_path}/overlays/"

    os.makedirs(overlays_rgba_root, exist_ok=True)
    os.makedirs(overlays_root, exist_ok=True)
    overlayed_img = overlayed_imgs[0]
    imageio.imwrite(f"{overlays_rgba_root}/{track_idx:04}.png",
                    (overlayed_img*255).astype(np.uint8))
    white_bg_img = convert_RGBA_to_RGB(overlayed_img)
    imageio.imwrite(f"{overlays_root}/{track_idx:04}.png",
                    (white_bg_img*255).astype(np.uint8))
    for inst_token, inst_rend_data in track_inst_imgs.items():
        base_inst_root = f"{store_path}/base_rends/{inst_token}/"
        os.makedirs(base_inst_root, exist_ok=True)
        for track_idx, base_img in enumerate(inst_rend_data['base_imgs']):
            imageio.imwrite(f"{base_inst_root}/{track_idx:04}.png",
                            (base_img*255).astype(np.uint8))


def create_gif(root_dir):
    from moviepy.editor import ImageSequenceClip
    from pathlib import Path
    vid = []
    for img_path in sorted([x for x in Path(root_dir).iterdir()]):
        if img_path.suffix in [".png", ".jpg"]:
            img = np.array(imageio.imread(img_path))
            vid.append(img)

    num_steps = min(len(vid), 20)
    clip = ImageSequenceClip(vid, fps=num_steps // 2)
    clip.write_gif(f"{root_dir}/vid.gif", fps=num_steps //
                   2, verbose=False, logger=None)
