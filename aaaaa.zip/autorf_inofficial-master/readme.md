# AutoRF (Inofficial release)

<p align="center"><a  target="_blank" rel="noopener noreferrer"><img width="50%" src="./static/teaser.png"></a></p>
<p align="center">
 <div align="center">
                            <span>
                                <a href="https://niessnerlab.org/members/norman_mueller/profile.html">Norman
                                    Müller</a><sup>1,3</sup>,</span>
                            <span>
                                <a href="https://simonelli-andrea.github.io/">Andrea Simonelli</a><sup>2,3</sup>,</span>
                            <span>
                                <a href="https://scholar.google.com/citations?user=vW1gaVEAAAAJ">Lorenzo
                                    Porzi</a><sup>3</sup>,
                            </span>
                            <span>
                                <a href="https://scholar.google.com/citations?hl=de&user=484sccEAAAAJ">Samuel Rota
                                    Bulò</a><sup>3</sup>,
                            </span>
                            <span>
                                <a href="https://niessnerlab.org/members/matthias_niessner/profile.html">Matthias
                                    Nießner</a><sup>1</sup>,
                            </span>
                            <span>
                                <a href="https://scholar.google.com/citations?user=CxbDDRMAAAAJ&hl=en">Peter
                                    Kontschieder</a><sup>3</sup>
                            </span>
                        </div>
             <div align="center">
                            <span><sup>1</sup>Technical University of Munich,</span>
                            <span><sup>2</sup>University of Trento,</span>
                            <span><sup>3</sup>Meta Reality Labs</span>
                        </div>
</p>


## Setup
Install the requirements using conda:
```
conda env create -f environment.yaml
conda activate autorf
pip install -r requirements.txt
```


## Data
For the unofficial release, we provide a script to download the pre-processed data (please to not share this data!) together with a checkpoint.
The full data generation scripts will follow with the official release.
```
python prepare_data.py
```
## Train
To train on NuScenes data, run the following command
```
python train.py --conf conf/nusc/nusc_train.conf
```
Choose your favorite logger (support for tensorboard,wandb) by setting logger=<logger_name> in the config or by running with
```
python train.py --conf conf/nusc/nusc_train.conf -logger <logger_name>
```

## Test
Render novel views for evaluation using the provided checkpoint
```
python test.py --conf conf/nusc/nusc_train_ckpt.conf
```
Evaluate results
```
python evaluate.py --rend_root render_novel --data_root data/full_val_nusc_v1_0 
```
## Visualize
We provide some sample camera tracks (auto-generated orbits around the center of the annotated objects).
To render using those and the provided checkpoint, run:
```
python vis.py --conf conf/nusc/nusc_train_ckpt.conf
```
Resulting images/videso are stored in: autorf_track_renders

E.g. autorf_track_renders/3edd8c1ef10b4f4e889e016cb56035e6/overlays/vid.gif
