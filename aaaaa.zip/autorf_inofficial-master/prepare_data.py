import os
import gdown
import tarfile
from argparse import ArgumentParser

parser = ArgumentParser()
parser.add_argument("--data_root", type=str, default="data")
args = parser.parse_args()

data_root = args.data_root

data_catalog = {
    "pano_out": {
        "url": "https://drive.google.com/u/0/uc?id=1YLSN4BFuuVZD7jadwy3TOVCdxuZiv7br&export=download",
        "store_fn": "pano_out.tar.gz",
        "extract_fn": "pano_out",
    },
    "nusc_v0_2": {
        "url": "https://drive.google.com/u/0/uc?id=1nV4OMQaG08pqb1ZZGZNO65SqKf-BSPpx&export=download",
        "store_fn": "nusc_v0_2.tar.gz",
        "extract_fn": "nusc_v0_2",
    },
    "full_val_nusc_v1_0": {
        "url": "https://drive.google.com/u/0/uc?id=1dccIg4qeg6TYn9koOFnxPKsEXrB25Mp7&export=download",
        "store_fn": "full_val_nusc_v1_0.tar.gz",
        "extract_fn": "full_val_nusc_v1_0"
    },
    "novel_views": {
        "url": "https://drive.google.com/u/0/uc?id=1ea7SrbCU-1X4EMnGhyK86aIq4b0GkwJA&export=download",
        "store_fn": "novel_views.pkl",
    },
    "nusc_v0_2_ckpt": {
        "url": "https://drive.google.com/u/0/uc?id=18wGoIicwC1yc92p2lPOQE5VM_nDRN7Ry&export=download",
        "store_fn": "nusc_v0_2.ckpt",
    },
    "sample_camera_tracks": {
        "url": "https://drive.google.com/u/0/uc?id=1tGy-nSJhS82sXXp3vuwmbFM57CiZ4Z_q&export=download",
        "store_fn": "sample_camera_tracks.tar.gz",
        "extract_fn": "sample_camera_tracks"
    },
    "cherry_examples": {
        "url": "https://drive.google.com/u/0/uc?id=1t-dWW4Jv3smdxSt_VSDPDW2ytWCdb3Gq&export=download",
        "store_fn": "cherry_nusc_v0_1.tar.gz",
        "extract_fn": "cherry_nusc_v0_1"
    },
}

os.makedirs(data_root, exist_ok=True)
for name, data_spec in data_catalog.items():
    print(f"Processing {name}")
    if not os.path.exists(f"{data_root}/{data_spec['store_fn']}"):
        gdown.download(data_spec["url"], f"{data_root}/{data_spec['store_fn']}")
    else:
        print(f"Skipping download for : {name}")
    if "extract_fn" in data_spec:
        if not os.path.exists(f"{data_root}/{data_spec['extract_fn']}"):
            tarfile.open(f"{data_root}/{data_spec['store_fn']}").extractall(
                f"{data_root}/{data_spec['extract_fn']}"
            )
        else:
            print(f"Skipping extract for : {name}")
