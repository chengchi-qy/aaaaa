from argconf import argconf_parse
from APSys.ap_builder import build_ap_sys
from ap_trainer import create_trainer, create_dataloader

from autorf import AutoRF, list_collate
from utils import seed_everything

if __name__ == "__main__":
    seed_everything(42)
    hparams = argconf_parse()
    # inference only support batch_size 1 atm
    hparams.train.batch_size_test = 1
    # create model
    model_conf = hparams.model
    ap_sys = build_ap_sys(model_conf.get("decoder"))
    # create lightning module
    ap_model = AutoRF(hparams, ap_sys)
    # create dataset 
    test_dataloader = create_dataloader(hparams, "test", list_collate)
    # create trainer
    trainer, hparams = create_trainer(hparams)
    # start training
    trainer.test(ap_model, dataloaders=test_dataloader, ckpt_path=hparams.run.ckpt_path)
    
