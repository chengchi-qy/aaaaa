from argconf import argconf_parse
from APSys.ap_builder import build_ap_sys
from ap_trainer import create_trainer, create_dataloader

from autorf import AutoRF, list_collate
from utils import seed_everything

if __name__ == "__main__":
    seed_everything(42)
    hparams = argconf_parse()
    # create model
    model_conf = hparams.model
    ap_sys = build_ap_sys(model_conf.get("decoder"))
    # create lightning module
    ap_model = AutoRF(hparams, ap_sys)
    # create dataset 
    train_dataloader = create_dataloader(hparams, "train", list_collate)
    val_dataloader = create_dataloader(hparams, "val", list_collate)
    # create trainer
    trainer, hparams = create_trainer(hparams)
    # start training
    trainer.fit(ap_model,train_dataloaders=train_dataloader, val_dataloaders=val_dataloader, ckpt_path=hparams.run.ckpt_path)
    
