from PIL import Image, ImageFont, ImageDraw
import numpy as np


def flatten_along_axis(mm):
    # convert [m1, m2, m3,...] with m1 = h1x... into row-first flat
    flat_mm = []
    max_h = max([m.shape[0] for m in mm])
    for k in range(max_h):
        for m in mm:
            if k < m.shape[0]:
                flat_mm.append(m[k])
            else:
                flat_mm.append(None)
    return flat_mm


def get_text_dimensions(text_string, font):
    # https://stackoverflow.com/a/46220683/9263761
    ascent, descent = font.getmetrics()

    text_width = font.getmask(text_string).getbbox()[2]
    text_height = font.getmask(text_string).getbbox()[3] + descent

    return (text_width, text_height)


def text2img(text, w, h, bg="white", color="black"):
    bb = Image.new("RGB", (w, h), color=bg)
    try:
        font_rsc = "arial.ttf"
        font_size = 1
        font = ImageFont.truetype(font_rsc, font_size, layout_engine=ImageFont.LAYOUT_BASIC)
        while get_text_dimensions(text, font)[1] < h - 3 and font_size < 100:
            # iterate until the text size is just larger than the criteria
            font_size += 1
            font = ImageFont.truetype(font_rsc, font_size, layout_engine=ImageFont.LAYOUT_BASIC)
        font = ImageFont.truetype(font_rsc, font_size - 1, layout_engine=ImageFont.LAYOUT_BASIC)

        d = ImageDraw.Draw(bb)
        text_w, text_h = font.getsize(text)
        d.text(((w - text_w) / 2, (h - text_h) / 2), text, fill=color, align="center", font=font)
    except:
        print(f"Error at ({h},{w}) with text: {text}")
    return np.array(bb)


def create_img_grid(imgs, titles, rows, cols, text_height=10, col_pad=3, bg="white", txt_col="black", txt_bg=None):
    # pad + rescale
    max_width, max_height = 0, 0
    for img in imgs:
        if img is not None:
            max_height = max(max_height, img.shape[0])
            max_width = max(max_width, img.shape[1])
    padded_imgs = []
    for img in imgs:
        padded_img = np.zeros((max_height, max_width, 3))
        if img is not None: #blank filling image
            padded_start = ((max_height - img.shape[0]) // 2, (max_width - img.shape[1]) // 2)
            padded_img[
                padded_start[0] : (padded_start[0] + img.shape[0]), padded_start[1] : (padded_start[1] + img.shape[1])
            ] = img
        padded_imgs.append(padded_img)
    imgs = padded_imgs

    # get image dimensions
    width = 0
    height = 0
    img_idx = 0
    for row in range(rows):
        for col in range(cols):
            if len(imgs) <= img_idx:
                break
            img = imgs[img_idx]
            if row == 0:
                width += img.shape[1]
            if col == 0:
                height += img.shape[0]
            img_idx += 1

    if text_height < 1:
        text_height = int(height / rows * text_height)
    if col_pad < 1:
        col_pad = int(width / cols * col_pad)
    if txt_bg is None:
        txt_bg = bg

    max_1 = img.max() <= 1
    canvas = np.array(Image.new("RGB", (1, 1), color=bg))
    bg_col = canvas[0, 0]
    if max_1:
        bg_col = bg_col / 255
    canvas_rows = []
    img_idx = 0
    for row in range(rows):
        canvas_row = []
        for col in range(cols):
            if len(imgs) <= img_idx:
                break
            img = imgs[img_idx]
            title = "-"
            if img_idx < len(titles):
                title = titles[img_idx]
                title_img = text2img(title, img.shape[1], text_height, txt_bg, txt_col)

            if max_1:
                title_img = title_img / 255
            labeled_img = np.concatenate([title_img, img], 0)
            if col > 0:
                col_padding = np.ones((labeled_img.shape[0], col_pad, 3)) * bg_col
                labeled_img = np.concatenate([col_padding, labeled_img], 1)
            canvas_row.append(labeled_img)
            img_idx += 1
        canvas_rows.append(np.concatenate(canvas_row, 1))
    np_canvas = np.concatenate(canvas_rows, 0)
    # add image padding
    full_canvas = np.ones((np_canvas.shape[0] + 2 * col_pad, np_canvas.shape[1] + 2 * col_pad, 3)) * bg_col
    full_canvas[col_pad:-col_pad, col_pad:-col_pad] = np_canvas
    return full_canvas