import os
import torch
import torch.nn.functional as F
import glob
import imageio
import numpy as np
import pickle
from torchvision import transforms
import hashlib

import copy



def get_image_to_tensor_balanced(image_size=0):
    ops = []
    if image_size > 0:
        ops.append(transforms.Resize(image_size))
    ops.extend(
        [transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),]
    )
    return transforms.Compose(ops)


def get_mask_to_tensor():
    return transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.0,), (1.0,))])


def int_hash(x):
    return int(hashlib.sha1(x.encode("utf-8")).hexdigest(), 16) % (10 ** 8)

class NuscenesDataset(torch.utils.data.Dataset):
    def __init__(self, root_dir, split="train",  data_conf=None):
        super().__init__()
        if split == "test":
            # novel evaluation on fixed subset
            self.base_path = root_dir + "_" + "val"
            self.novel_pairs = pickle.load(open( os.path.expanduser(data_conf.novel_pairs_fn), "rb"))
            self.novel_pairs_flat = []
            print("DEBUGGING")
            for inst_fn, final_pairs in self.novel_pairs.items():
                for src_idx, target_inds in final_pairs.items():
                    # if "2cf07ee07f954934b7128c79569f4902" in str(inst_fn):
                    self.novel_pairs_flat.append((inst_fn, src_idx, target_inds))
        elif split == "vis":
            # for frame-based inference
            self.base_path = root_dir
            subset_fns = data_conf.subset_fns
            resolved_subset_fns = []
            for sub_fn in subset_fns:
                if "*" in sub_fn:
                    resolved_subset_fns += [x for x in glob.glob(f"{self.base_path}/{sub_fn}")]
                else:
                    resolved_subset_fns.append(sub_fn)
            self.sample_dirs = resolved_subset_fns

        elif split == "trainval":
            self.base_path = root_dir + "_" + "train"
        else:
            self.base_path = root_dir + "_" + split
        self.dataset_name = os.path.basename(root_dir)

        print(f"Loading dataset from {self.base_path} name: {self.dataset_name}")
        self.split = split
        assert os.path.exists(self.base_path), f"{self.base_path} not found"

        # overfitting logic for debugging
        overfit = data_conf.get("overfit")
        self.overfit = overfit
        if overfit is not None and split not in ["test", "vis"]:
            # ( num_reps, fn)
            self.sample_dirs = (300 if split=='train' else 1) * [overfit]
        else:
            if split == "vis":
                pass
            else:
                self.sample_dirs = list(sorted(glob.glob(self.base_path + "/*")))
        
        if self.split == "val" and data_conf.get("val_num") is not None:
            self.sample_dirs = self.sample_dirs[:data_conf.val_num]

        print(f"Num samples: {len(self.sample_dirs)}")

        self.image_to_tensor = get_image_to_tensor_balanced()
        self.mask_to_tensor = get_mask_to_tensor()

        self.image_size = data_conf.image_size

        if self.split == "train":
            self.nsource_views = data_conf.get("train_nsource_views", 0)
            self.ntarget_views = data_conf.get("train_ntarget_views", 0)
        elif self.split in ["val", "test", "trainval"]:
            self.nsource_views = data_conf.get("test_nsource_views", 0)
            self.ntarget_views = data_conf.get("test_ntarget_views", 0)
        elif self.split == 'vis':
            self.nsource_views = 1
            self.ntarget_views = 0
        else:
            raise NotImplementedError

        self.nviews = self.nsource_views + self.ntarget_views
        self.det_random = data_conf.get("det_random", False)

        self.fixed_bound = data_conf.get("fixed_bound", None)
        # image resizing
        self.image_mode = data_conf.get("image_mode", "resize_min_max")
        self.resize_min_size = data_conf.get("resize_min_size", 32)
        self.resize_max_size = data_conf.get("resize_max_size", 360)
        self.fixed_size = data_conf.get("fixed_size", None)

        self.enc_image_mode = data_conf.get("enc_image_mode", None)
        self.enc_resize_min_size = data_conf.get("enc_resize_min_size", 32)
        self.enc_resize_max_size = data_conf.get("enc_resize_max_size", 360)
        self.enc_fixed_size = data_conf.get("enc_fixed_size", None)

        # obj space
        self.obj_space = data_conf.get("obj_space", "obj")

        # flipping background
        self.flipping_bg = data_conf.get("flipping_bg", None)
        self.unknown_color = data_conf.get("unknown_color", "black")

        print(f"Num samples {split}: {len(self)}")

    def __len__(self):
        if self.split == "test":
            return  len(self.novel_pairs_flat)
        return len(self.sample_dirs)

    def __getitem__(self, index):
        if self.split == "test":
            dir_path, src_idx, target_inds = self.novel_pairs_flat[index]

            src_idx = int(src_idx)
            target_inds = [int(x) for x in target_inds]
            image_inds = [src_idx] + target_inds
            dir_path = str(dir_path)
        else:
            dir_path = self.sample_dirs[index]
            anno_paths = sorted(glob.glob(os.path.join(dir_path, "annotation", "*")))
            image_inds = [int(rgb_path.split("/")[-1].split(".")[0]) for rgb_path in anno_paths]

            if self.det_random:
                np.random.seed(int_hash(dir_path))
                if len(image_inds) >= self.nviews:
                    image_inds = np.random.choice(image_inds, self.nviews, replace=False)
                else:
                    image_inds = np.random.choice(image_inds, self.nviews, replace=True)

            else:
                if len(image_inds) >= self.nviews:
                    image_inds = np.random.choice(image_inds, self.nviews, replace=False)
                else:
                    image_inds = np.random.choice(image_inds, self.nviews, replace=True)

        
        all_enc_imgs = []
        all_imgs = []
        all_poses = []
        all_intrinsics = []
        all_intrinsics_org = []
        all_cam_K_org = []
        # all_izposes_so3 = []
        all_enc_fb_masks = []
        all_fb_masks = []
        all_bboxes = []
        all_obj2cans = []

        for image_idx in image_inds:
            rgb_masked_path = f"{dir_path}/rgb_masked/{image_idx}.jpg"
            fb_mask_path = f"{dir_path}/fb_mask/{image_idx}.png"
            anno_path = f"{dir_path}/annotation/{image_idx}.pkl"

            img = imageio.imread(rgb_masked_path)[..., :3]
            fb_mask = torch.from_numpy(np.array(imageio.imread(fb_mask_path)))
            annotation = pickle.load(open(anno_path, "rb"))

            img_tensor = self.image_to_tensor(img)
            if self.flipping_bg == "white":
                img_tensor[:, fb_mask == 0] = 1
            elif self.flipping_bg == "rand_white" and np.random.rand() > 0.5:
                img_tensor[:, fb_mask == 0] = 1

            if self.unknown_color == "black":
                pass  # rgb mask already black at unknown
            elif self.unknown_color == "white":
                img_tensor[:, fb_mask == 2] = 1

            obj2cam = annotation["obj2cam"]
            cam2obj = np.linalg.inv(obj2cam)

            if self.obj_space == "obj":
                pose = torch.from_numpy(cam2obj).float()
                obj2can = np.eye(4)
                correcting_flip = torch.diag(torch.tensor([1.0, 1, -1, 1]))
            elif self.obj_space == "obj_o":
                obj2obj_o = annotation["obj2obj_o"]
                obj2can = obj2obj_o
                pose = torch.from_numpy(obj2can @ cam2obj).float()
                correcting_flip = torch.eye(4)
            elif self.obj_space == "iso_obj":
                obj2iso_obj = annotation["obj2iso_obj"]
                obj2can = obj2iso_obj
                pose = torch.from_numpy(obj2can @ cam2obj).float()
                correcting_flip = torch.diag(torch.tensor([1.0, 1, -1, 1]))
            elif self.obj_space == "iso_obj_o":
                obj2obj_o = annotation["obj2obj_o"]
                obj2iso_obj = annotation["obj2iso_obj"]
                obj2can = obj2obj_o @ obj2iso_obj
                pose = torch.from_numpy(obj2can @ cam2obj).float()
                correcting_flip = torch.eye(4)
            else:
                raise NotImplementedError

            # possible perturbation
            can2cam = torch.inverse(pose)
            intrinsics = torch.from_numpy(annotation["cam_K"])
            intrinsics_org = torch.from_numpy(annotation["cam_K_org"])
            cam_K_org = torch.from_numpy(annotation["cam_K_org"])

            # CAREFUL!
            # only works for single view!
            focal_xy = np.array([intrinsics[0, 0], intrinsics[1, 1]])
            cx = intrinsics[0, 2]
            cy = intrinsics[1, 2]

            rows = torch.any(fb_mask > 0, 1)
            cols = torch.any(fb_mask > 0, 0)
            rnz = torch.where(rows)[0]
            cnz = torch.where(cols)[0]
            rmin, rmax = rnz[[0, -1]]
            cmin, cmax = cnz[[0, -1]]
            bbox = torch.tensor([cmin, rmin, cmax, rmax], dtype=torch.float32)

            all_imgs.append(img_tensor)
            all_fb_masks.append(fb_mask)
            all_poses.append(pose)
            all_intrinsics.append(intrinsics)
            all_intrinsics_org.append(intrinsics_org)
            all_cam_K_org.append(cam_K_org)
            all_bboxes.append(bbox)
            all_obj2cans.append(torch.from_numpy(obj2can))

        all_poses = torch.stack(all_poses)
        all_intrinsics = torch.stack(all_intrinsics)
        all_intrinsics_org = torch.stack(all_intrinsics_org)
        all_cam_K_org = torch.stack(all_cam_K_org)
        # all_izposes_so3 = torch.stack(all_izposes_so3)
        all_bboxes = torch.stack(all_bboxes)
        all_obj2cans = torch.stack(all_obj2cans)


        if self.enc_image_mode is not None:
            all_enc_imgs = copy.deepcopy(all_imgs)
            all_enc_fb_masks = copy.deepcopy(all_fb_masks)
            # different image res for encoder than for rendering
            for idx in range(len(all_enc_imgs)):
                if self.enc_image_mode == "resize_min_max":
                    # resize to min, max image size
                    min_size, max_size = self.enc_resize_min_size, self.enc_resize_max_size
                    aspect_ratio = all_enc_imgs[idx].shape[2] / all_enc_imgs[idx].shape[1]
                    new_size = np.array([(all_enc_imgs[idx].shape[1]), (all_enc_imgs[idx].shape[2])])
                    if new_size[0] < min_size:
                        new_size[0] = min_size
                        new_size[1] = aspect_ratio * new_size[0]  # max(new_size[1],)
                    if new_size[1] < min_size:
                        new_size[1] = min_size
                        new_size[0] = 1 / aspect_ratio * new_size[1]  # max(new_size[0],)

                    if new_size[0] > max_size:
                        new_size[0] = max_size
                        new_size[1] = aspect_ratio * new_size[0]  # max(new_size[1],)

                    if new_size[1] > max_size:
                        new_size[1] = max_size
                        new_size[0] = 1 / aspect_ratio * new_size[1]  # max(new_size[0],)

                elif self.enc_image_mode == "fixed_size":
                    new_size = np.array(self.enc_fixed_size)
                else:
                    continue

                all_enc_imgs[idx] = F.interpolate(all_enc_imgs[idx].unsqueeze(0), size=tuple(new_size), mode="area")[0]
                all_enc_fb_masks[idx] = F.interpolate(
                    all_enc_fb_masks[idx].unsqueeze(0).unsqueeze(0), size=tuple(new_size), mode="nearest"
                )[0][0]

        # resizing logic
        # 1. no resizing
        # *2. resize to min, max image size
        # 3. 1 image size
        # 4. 1 image size, pad to preserve aspect ratio
        # 5. dynamic (min/max) image size, pad to preserve aspect ratio

        for idx in range(len(all_imgs)):
            if self.image_mode == "resize_min_max":
                # resize to min, max image size
                min_size, max_size = self.resize_min_size, self.resize_max_size
                aspect_ratio = all_imgs[idx].shape[2] / all_imgs[idx].shape[1]
                new_size = np.array([(all_imgs[idx].shape[1]), (all_imgs[idx].shape[2])])
                if new_size[0] < min_size:
                    new_size[0] = min_size
                    new_size[1] = aspect_ratio * new_size[0]  # max(new_size[1],)
                if new_size[1] < min_size:
                    new_size[1] = min_size
                    new_size[0] = 1 / aspect_ratio * new_size[1]  # max(new_size[0],)

                if new_size[0] > max_size:
                    new_size[0] = max_size
                    new_size[1] = aspect_ratio * new_size[0]  # max(new_size[1],)

                if new_size[1] > max_size:
                    new_size[1] = max_size
                    new_size[0] = 1 / aspect_ratio * new_size[1]  # max(new_size[0],)

            elif self.image_mode == "fixed_size":
                new_size = np.array(self.fixed_size)
            else:
                continue

            scale_y = new_size[0] / all_imgs[idx].shape[-2]
            scale_x = new_size[1] / all_imgs[idx].shape[-1]

            intrinsics = all_intrinsics[idx]
            intrinsics[0, 0] *= scale_x
            intrinsics[1, 1] *= scale_y
            intrinsics[0, 2] *= scale_x
            intrinsics[1, 2] *= scale_y
            intrinsics_org = all_intrinsics_org[idx]
            intrinsics_org[0, 0] *= scale_x
            intrinsics_org[1, 1] *= scale_y
            intrinsics_org[0, 2] *= scale_x
            intrinsics_org[1, 2] *= scale_y

            all_intrinsics[idx] = intrinsics
            all_intrinsics_org[idx] = intrinsics_org

            all_imgs[idx] = F.interpolate(all_imgs[idx].unsqueeze(0), size=tuple(new_size), mode="area")[0]
            all_fb_masks[idx] = F.interpolate(all_fb_masks[idx].unsqueeze(0).unsqueeze(0), size=tuple(new_size), mode="nearest")[
                0
            ][0]

            focal_xy = np.array([focal_xy[0] * scale_x, focal_xy[1] * scale_y])
            cx *= scale_x
            cy *= scale_y
            all_bboxes[idx, [0, 2]] *= scale_x
            all_bboxes[idx, [1, 3]] *= scale_y
        if self.enc_image_mode is None:
            all_enc_imgs = copy.deepcopy(all_imgs)
            all_enc_fb_masks = copy.deepcopy(all_fb_masks)
       

        all_masks = [x.unsqueeze(0) for x in all_fb_masks]
        if len(image_inds) == 1:
            all_imgs = torch.stack(all_imgs)
            all_fb_masks = torch.stack(all_fb_masks)
            all_masks = torch.stack(all_masks)
            all_enc_imgs = torch.stack(all_enc_imgs)
            all_enc_fb_masks = torch.stack(all_enc_fb_masks)


        if self.fixed_bound is None:
            bound = torch.Tensor(self.fixed_bound)
        else:
            bound = torch.Tensor([0.5])


        result = {
            "path": dir_path,
            "inst_token": dir_path.split("/")[-1],
            "img_id": index,
            "intrinsics": all_intrinsics.float(),
            "intrinsics_org": all_intrinsics_org.float(),
            "cam_K_org": all_cam_K_org.float(),
            "images": all_imgs,
            "fb_masks": all_fb_masks,
            "bbox": all_bboxes,
            "poses": all_poses.float(),
            "image_ids": image_inds,
            "bound": bound,
            "obj2cans": all_obj2cans,
            # backwards compability
            "focal_xy": torch.tensor(focal_xy, dtype=torch.float32),
            "c": torch.tensor([cx, cy], dtype=torch.float32),
            "masks": all_masks,
            # encoder with different image
            "enc_images": all_enc_imgs,
            "enc_fb_masks": all_enc_fb_masks,

            "n_source": self.nsource_views,
            "n_target": self.ntarget_views,
        }
        if self.split == "test":
            result.update({"n_source": 1, "n_target": len(target_inds)})
        return result
