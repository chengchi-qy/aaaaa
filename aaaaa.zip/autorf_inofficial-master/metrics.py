import torch
import numpy as np
from einops import rearrange

def mse(image_pred, image_gt, valid_mask=None, reduction="mean"):
    value = (image_pred - image_gt) ** 2
    if valid_mask is not None:
        value = value[valid_mask]
    if reduction == "mean":
        return torch.mean(value)
    return value


def psnr(image_pred, image_gt, valid_mask=None, reduction="mean"):
    return -10 * torch.log10(mse(image_pred, image_gt, valid_mask, reduction))


def ssim(pred, target, mask=None):
    # from skimage.measure import compare_ssim
    from skimage.metrics import structural_similarity
    if isinstance(pred, torch.Tensor):
        pred = pred.detach().cpu().numpy()
    if isinstance(target, torch.Tensor):
        target = target.detach().cpu().numpy()
    if isinstance(mask, torch.Tensor):
        mask = mask.detach().cpu().numpy()
    if mask is None:
        # ssim = compare_ssim(pred, target, multichannel=True, data_range=1)
        ssim = structural_similarity(pred, target, multichannel=True, data_range=1)
    else:
        pred_masked = np.copy(pred)
        target_masked = np.copy(target)
        pred_masked[~mask] = 0
        target_masked[~mask] = 0
        if len(pred_masked.shape) == 5:
            pred_masked = rearrange(pred_masked,"B V H W C -> (B V) H W C")
            target_masked = rearrange(target_masked,"B V H W C -> (B V) H W C")
        if len(pred_masked.shape) == 4:
            single_ssim = []
            for bv in range(pred_masked.shape[0]):
                ssim = structural_similarity(pred_masked[bv], target_masked[bv], multichannel=True, data_range=1)
                single_ssim.append(ssim)
            ssim = np.mean(single_ssim)
        else:
            ssim = structural_similarity(pred_masked, target_masked, multichannel=True, data_range=1)
    return ssim