from .ap_sys import APSys
from . import autorf_decoder
from . import autorf_conditioners

def build_ap_sys( dec_conf) -> APSys:
    ap_dcond = None
    ap_dec = None
    if dec_conf is not None:
        if dec_conf.get("conditioner") is not None:
            ap_dcond = getattr(autorf_conditioners, dec_conf.conditioner.name)(**dec_conf.conditioner)
        ap_dec = getattr(autorf_decoder,dec_conf.name)(**dec_conf)

    return APSys(d_conditioner=ap_dcond, decoder=ap_dec)
