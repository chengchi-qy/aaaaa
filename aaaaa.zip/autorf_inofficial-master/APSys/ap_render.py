import torch
from torch.nn import functional as F
from dvis import dvis
from einops import rearrange, repeat
from .ap_sys import APSys


def near_far_from_bound(rays_o, rays_d, bound, type="cube"):
    # rays: [B, N, 3], [B, N, 3]
    # bound: int, radius for ball or half-edge-length for cube
    # return near [B, N, 1], far [B, N, 1]

    radius = rays_o.norm(dim=-1, keepdim=True)

    if type == "sphere":
        near = radius - bound  # [B, N, 1]
        far = radius + bound

    elif type == "cube":
        tmin = (-bound - rays_o) / (rays_d + 1e-15)  # [B, N, 3]
        tmax = (bound - rays_o) / (rays_d + 1e-15)
        near = torch.where(tmin < tmax, tmin, tmax).max(dim=-1, keepdim=True)[0]
        far = torch.where(tmin > tmax, tmin, tmax).min(dim=-1, keepdim=True)[0]
        # if far < near, means no intersection, set both near and far to inf (1e9 here)
        mask = far < near
        near[mask] = 1e9
        far[mask] = 1e9
        # restrict near to a minimal value
        near = torch.clamp(near, min=0.05)

    return near, far

# calculate color
def sigmoid_t(x, t=1):
    return 1 / (1 + torch.exp(-x * t))


def ww(x, t=50):
    return 1 - sigmoid_t(x - 2 / t, t)


def sample_pdf(bins, weights, n_samples, det=False):
    # This implementation is from NeRF
    # bins: [B, T], old_z_vals
    # weights: [B, T - 1], bin weights.
    # return: [B, n_samples], new_z_vals

    # Get pdf
    weights = weights + 1e-5  # prevent nans
    pdf = weights / torch.sum(weights, -1, keepdim=True)
    cdf = torch.cumsum(pdf, -1)
    cdf = torch.cat([torch.zeros_like(cdf[..., :1]), cdf], -1)
    # Take uniform samples
    if det:
        u = torch.linspace(0.0 + 0.5 / n_samples, 1.0 - 0.5 / n_samples, steps=n_samples).to(weights.device)
        u = u.expand(list(cdf.shape[:-1]) + [n_samples])
    else:
        u = torch.rand(list(cdf.shape[:-1]) + [n_samples]).to(weights.device)

    # Invert CDF
    u = u.contiguous()
    inds = torch.searchsorted(cdf, u, right=True)
    below = torch.max(torch.zeros_like(inds - 1), inds - 1)
    above = torch.min((cdf.shape[-1] - 1) * torch.ones_like(inds), inds)
    inds_g = torch.stack([below, above], -1)  # (B, n_samples, 2)

    matched_shape = [inds_g.shape[0], inds_g.shape[1], cdf.shape[-1]]
    cdf_g = torch.gather(cdf.unsqueeze(1).expand(matched_shape), 2, inds_g)
    bins_g = torch.gather(bins.unsqueeze(1).expand(matched_shape), 2, inds_g)

    denom = cdf_g[..., 1] - cdf_g[..., 0]
    denom = torch.where(denom < 1e-5, torch.ones_like(denom), denom)
    t = (u - cdf_g[..., 0]) / denom
    samples = bins_g[..., 0] + t * (bins_g[..., 1] - bins_g[..., 0])

    return samples


def ap_render(
    ap_sys: APSys,
    rays_o,
    rays_d,
    bound,
    num_steps,
    upsample_steps,
    bg_color,
    perturb,
    b_idx=None,
    bound_type="cube",
    normalize_pts=True,
    condition=None,
    softplus_shift=None,
    recolor_weight=0,
    d_cond=None
):
    # rays_o, rays_d: [B, N, 3], assumes B == 1
    # bg_color: [3] in range [0, 1]
    # return: image: [B, N, 3], depth: [B, N]

    B, N = rays_o.shape[:2]
    device = rays_o.device

    # sample steps
    near, far = near_far_from_bound(rays_o, rays_d, bound, type=bound_type)
    # near = torch.clamp(near, max=bound * 3)
    # far = torch.clamp(far, max=bound * 3 + 0.1)

    # print(f'near = {near.min().item()} ~ {near.max().item()}, far = {far.min().item()} ~ {far.max().item()}')

    z_vals = torch.linspace(0.0, 1.0, num_steps, device=device).unsqueeze(0).unsqueeze(0)  # [1, 1, T]
    z_vals = z_vals.expand((B, N, num_steps))  # [B, N, T]
    z_vals = near + (far - near) * z_vals  # [B, N, T], in [near, far]

    # perturb z_vals
    sample_dist = (far - near) / num_steps
    if perturb:
        z_vals = z_vals + (torch.rand(z_vals.shape, device=device) - 0.5) * sample_dist
        # z_vals = z_vals.clamp(near, far) # avoid out of bounds pts.

    # generate pts
    pts = rays_o.unsqueeze(-2) + rays_d.unsqueeze(-2) * z_vals.unsqueeze(-1)  # [B, N, 1, 3] * [B, N, T, 3] -> [B, N, T, 3]
    pts = pts.clamp(-bound, bound)  # must be strictly inside the bounds, else lead to nan in hashgrid encoder!
    if normalize_pts:
        pts /= bound

    dirs = rays_d.unsqueeze(-2).expand_as(pts)
    apps = ap_sys.decode(pts=pts.reshape(B, -1, 3), viewdirs=dirs.reshape(B, -1, 3), cond=condition, b_idx=b_idx, d_cond=d_cond)
    if softplus_shift is not None:
        sigmas = F.softplus(apps[..., :1] + softplus_shift)
    else:
        sigmas = F.relu(apps[..., :1])
    rgbs = torch.sigmoid(apps[..., 1:])

    rgbs = rgbs.reshape(B, N, num_steps, 3)  # [B, N, T, 3]
    sigmas = sigmas.reshape(B, N, num_steps)  # [B, N, T]

    # upsample z_vals (nerf-like)
    if upsample_steps > 0:
        with torch.no_grad():

            deltas = z_vals[:, :, 1:] - z_vals[:, :, :-1]  # [B, N, T-1]
            deltas = torch.cat([deltas, sample_dist * torch.ones_like(deltas[:, :, :1])], dim=-1)

            alphas = 1 - torch.exp(-deltas * sigmas)  # [B, N, T]
            alphas_shifted = torch.cat([torch.ones_like(alphas[:, :, :1]), 1 - alphas + 1e-15], dim=-1)  # [B, N, T+1]
            weights = alphas * torch.cumprod(alphas_shifted, dim=-1)[:, :, :-1]  # [B, N, T]

            # sample new z_vals
            z_vals_mid = z_vals[:, :, :-1] + 0.5 * deltas[:, :, :-1]  # [B, N, T-1]
            new_z_vals = sample_pdf(
                z_vals_mid.reshape(B * N, -1), weights.reshape(B * N, -1)[:, 1:-1], upsample_steps, det=not perturb
            ).detach()  # [BN, t]
            new_z_vals = new_z_vals.reshape(B, N, upsample_steps)

            new_pts = rays_o.unsqueeze(-2) + rays_d.unsqueeze(-2) * new_z_vals.unsqueeze(
                -1
            )  # [B, N, 1, 3] * [B, N, t, 3] -> [B, N, t, 3]
            new_pts = new_pts.clamp(-bound, bound)

        # only forward new points to save computation
        new_dirs = rays_d.unsqueeze(-2).expand_as(new_pts)

        new_apps = ap_sys.decode(pts=new_pts.reshape(B, -1, 3), viewdirs=new_dirs.reshape(B, -1, 3), cond=condition, d_cond=d_cond)
        if softplus_shift is not None:
            new_sigmas = F.softplus(new_sigmas[..., :1] + softplus_shift)
        else:
            new_sigmas = F.relu(new_apps[..., :1])
        new_rgbs = torch.sigmoid(new_apps[..., 1:])

        new_rgbs = new_rgbs.reshape(B, N, upsample_steps, 3)  # [B, N, t, 3]
        new_sigmas = new_sigmas.reshape(B, N, upsample_steps)  # [B, N, t]

        # re-order
        z_vals = torch.cat([z_vals, new_z_vals], dim=-1)  # [B, N, T+t]
        z_vals, z_index = torch.sort(z_vals, dim=-1)

        sigmas = torch.cat([sigmas, new_sigmas], dim=-1)  # [B, N, T+t]
        sigmas = torch.gather(sigmas, dim=-1, index=z_index)

        rgbs = torch.cat([rgbs, new_rgbs], dim=-2)  # [B, N, T+t, 3]
        rgbs = torch.gather(rgbs, dim=-2, index=z_index.unsqueeze(-1).expand_as(rgbs))

    ### render core
    deltas = z_vals[:, :, 1:] - z_vals[:, :, :-1]  # [B, N, T-1]
    deltas = torch.cat([deltas, sample_dist * torch.ones_like(deltas[:, :, :1])], dim=-1)

    alphas = 1 - torch.exp(-deltas * sigmas)  # [B, N, T]
    alphas_shifted = torch.cat([torch.ones_like(alphas[:, :, :1]), 1 - alphas + 1e-15], dim=-1)  # [B, N, T+1]
    weights = alphas * torch.cumprod(alphas_shifted, dim=-1)[:, :, :-1]  # [B, N, T]

    # calculate weight_sum (mask)
    acc_weight = weights.sum(dim=-1)  # [B, N]

    # calculate dist
    # ori_z_vals = ((z_vals - near) / (far - near)).clamp(0, 1)
    dist = torch.sum(weights * z_vals, dim=-1)

    # calculate color
    if recolor_weight > 0:
        # increase rgb of low weight points, so there is a gradient for those points
        re_col_w = ww(weights, t=100).unsqueeze(-1).detach()
        # image = torch.sum(weights.unsqueeze(-1) * ((1 - rgbs) * re_col_w + (1 - re_col_w) * rgbs), dim=-2)  # [B, N, 3], in [0, 1]
        image = torch.sum(weights.unsqueeze(-1) * (re_col_w + rgbs), dim=-2)  # [B, N, 3], in [0, 1]
    else:
        image = torch.sum(weights.unsqueeze(-1) * rgbs, dim=-2)  # [B, N, 3], in [0, 1]

    # mix background color
    if bg_color is None:
        bg_color = 1

    image = image + (1 - acc_weight).unsqueeze(-1) * bg_color

    return image, dist, acc_weight


def ap_render_staged(
    ap_sys,
    rays_o,
    rays_d,
    bound=1,
    num_steps=128,
    upsample_steps=128,
    staged=False,
    max_ray_batch=4096,
    bg_color=None,
    perturb=False,
    with_argmax_dist=False,
    normalize_pts=True,
    condition=None,
    softplus_shift=None,
    recolor_weight=0,
    d_cond=None,
    **kwargs,
):
    # rays_o, rays_d: [B, [V], N, 3]
    # return: pred_rgb: [B, [V], N, 3]
    HAS_V = False
    if len(rays_o.shape) == 4:
        # for internal ha
        HAS_V = True
        B, V, oN = rays_o.shape[:3]
        N = V * oN
        rays_o = rearrange(rays_o, "B V oN C -> B (V oN) C")
        rays_d = rearrange(rays_d, "B V oN C -> B (V oN) C")

    else:
        B, N = rays_o.shape[:2]

    device = rays_o.device

    # never stage when cuda_ray
    if staged:
        image = torch.empty((B, N, 3), device=device)
        dist = torch.empty((B, N), device=device)
        acc_weight = torch.empty((B, N), device=device)
        # argmax_dist = torch.empty((B, N), device=device)
        if d_cond is None and condition is not None:
            # precompute d_cond in case there are several inner loops of the same image
            b_d_cond = []
            for b_idx in range(B):
                b_d_cond+=(ap_sys.d_conditioner(condition[b_idx : b_idx + 1]))
            d_cond = b_d_cond

        for b_idx in range(B):
            head = 0

            while head < N:
                tail = min(head + max_ray_batch, N)
                image_, dist_, acc_weight_ = ap_render(
                    ap_sys,
                    rays_o[b_idx : b_idx + 1, head:tail],
                    rays_d[b_idx : b_idx + 1, head:tail],
                    bound,
                    num_steps,
                    upsample_steps,
                    bg_color,
                    perturb,
                    b_idx=b_idx,
                    normalize_pts=normalize_pts,
                    condition=condition[b_idx : b_idx + 1] if condition is not None else condition,
                    softplus_shift=softplus_shift,
                    recolor_weight=recolor_weight,
                    d_cond=d_cond[b_idx : b_idx +1] if d_cond is not None else d_cond,
                )
                image[b_idx : b_idx + 1, head:tail] = image_
                dist[b_idx : b_idx + 1, head:tail] = dist_
                acc_weight[b_idx : b_idx + 1, head:tail] = acc_weight_
                # argmax_dist[b : b + 1, head:tail] = argmax_dist_
                head += max_ray_batch
    else:
        image, dist, acc_weights = ap_render(
            ap_sys,
            rays_o,
            rays_d,
            bound,
            num_steps,
            upsample_steps,
            bg_color,
            perturb,
            normalize_pts=normalize_pts,
            condition=condition,
            softplus_shift=softplus_shift,
            recolor_weight=recolor_weight,
            d_cond=d_cond
        )
    if HAS_V:
        image = rearrange(image, "B (V oN) C -> B V oN C", V=V, oN=oN)
        dist = rearrange(dist, "B (V oN) -> B V oN", V=V, oN=oN)
        acc_weight = rearrange(acc_weight, "B (V oN) -> B V oN", V=V, oN=oN)

    results = {}
    results["rgb"] = image
    results["dist"] = dist
    results["acc_weight"] = acc_weight
    # results["argmax_dist"] = argmax_dist

    return results

