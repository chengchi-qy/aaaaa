import torch
from torch import nn
from typing import Optional


class APSys(nn.Module):
    def __init__(self, d_conditioner=None, decoder=None):
        super().__init__()
        self.d_conditioner = d_conditioner
        self.decoder = decoder

    def decode(self, pts: torch.Tensor, viewdirs: Optional[torch.Tensor] = None, cond: Optional[torch.Tensor] = None, b_idx: Optional[int] = None, d_cond: Optional[torch.Tensor] = None) -> torch.Tensor:
        """[Conditional] decoding of ap_rep to app

        Args:
            pts (torch.Tensor): [B,N,xyz] query points
            viewdirs (Optional[torch.Tensor]):  [B,N,C] query viewdirs
            cond (Optional[torch.Tensor]):  [B,N,C,...] condition for DConditioner
            b_idx (Optional[int]): for staged rendering, specifices batch index corresponding to the pts

        Returns:
            torch.Tensor: [B,N,D+C+[F]] app with [density, color, additional features]
        """
        rep_pts = pts  
        if d_cond is None and self.d_conditioner is not None:
            # if d_cond is precomputed -> skip
            d_cond = self.d_conditioner(cond=cond)
        if self.decoder is not None:
            app = self.decoder(rep_pts=rep_pts, pts=pts,
                               viewdirs=viewdirs, cond=d_cond)
        else:
            app = rep_pts  # if rep already stores app
        return app
