import os
import torch
from torch import nn
import numpy as np

from pytorch_lightning import LightningModule
from utils import  autorf_get_rays_v
from APSys.ap_render import ap_render_staged
from metrics import psnr, ssim, mse
from einops import rearrange
from vis_utils import create_img_grid, flatten_along_axis

import imageio
from collections import defaultdict


def restore_img(px_vals, H, W, px_inds=None, b_idx=0, bg=0):

    if len(px_vals.shape) == 4:
        B, V, _, C = px_vals.shape
        r_img = torch.ones(
            (B, V, H * W, C), device=px_vals.device, dtype=px_vals.dtype) * bg
    elif len(px_vals.shape) == 3:
        B, V, _ = px_vals.shape
        C = 0
        r_img = (torch.ones((B, V, H * W), device=px_vals.device,
                 dtype=px_vals.dtype) * bg)
    for b in range(B):
        for v in range(V):
            r_img[b, v][px_inds[b, v]] = px_vals[b, v]
    if C > 0:
        r_img = rearrange(r_img, "B V (H W) C -> B V H W C", H=H, W=W)
    else:
        r_img = rearrange(r_img, "B V (H W)-> B V H W", H=H, W=W)

    return r_img


def list_collate(batch):
    collated_batch = defaultdict(list)
    for sample in batch:
        for k, val in sample.items():
            collated_batch[k].append(val)
    for k, vals in collated_batch.items():
        # stack whenever shape allows
        if isinstance(vals[0], torch.Tensor):
            if np.all([vals[0].shape == val.shape for val in vals]):
                collated_batch[k] = torch.stack(vals)
        if isinstance(vals[0], np.ndarray):
            if np.all([vals[0].shape == val.shape for val in vals]):
                collated_batch[k] = np.stack(vals)
        # very hacky for batch,NV
        if isinstance(vals[0], list):
            if len(vals[0]) > 0:
                if isinstance(vals[0][0], torch.Tensor):
                    if np.all([vals[0][0].shape == val.shape for val in vals[0]]):
                        collated_batch[k] = torch.stack(
                            [torch.stack(v) for v in vals])
                elif isinstance(vals[0][0], np.ndarray):
                    if np.all([vals[0][0].shape == val.shape for val in vals[0]]):
                        collated_batch[k] = np.stack(
                            [np.stack(v) for v in vals])

    return collated_batch


def to_device(data, device):
    if isinstance(data, torch.Tensor):
        return data.to(device)
    elif isinstance(data, list):
        return [to_device(item, device) for item in data]
    elif isinstance(data, tuple):
        return (to_device(item, device) for item in data)
    else:
        raise NotImplementedError(f"Cannot transfer data of type {type(data)}")


def batch_index_select(data, b_inds):
    if isinstance(data, torch.Tensor):
        return data.gather(1, b_inds[(...,) + (None,) * (len(data.shape) - 2)].expand(-1, -1, *data.shape[2:]))
    elif isinstance(data, (list, tuple)):
        b_data = []
        for batch_idx in range(len(b_inds)):
            views_data = []
            for view_idx in b_inds[batch_idx]:
                views_data.append(data[batch_idx][view_idx])
            b_data.append(views_data)
        return b_data


# pose optimization at inference time
def convert3x4_4x4(input):
    """
    :param input:  (N, 3, 4) or (3, 4) torch or np
    :return:       (N, 4, 4) or (4, 4) torch or np
    """
    if torch.is_tensor(input):
        if len(input.shape) == 3:
            output = torch.cat([input, torch.zeros_like(
                input[:, 0:1])], dim=1)  # (N, 4, 4)
            output[:, 3, 3] = 1.0
        else:
            output = torch.cat([input, torch.tensor(
                [[0, 0, 0, 1]], dtype=input.dtype, device=input.device)], dim=0)  # (4, 4)
    else:
        if len(input.shape) == 3:
            output = np.concatenate(
                [input, np.zeros_like(input[:, 0:1])], axis=1)  # (N, 4, 4)
            output[:, 3, 3] = 1.0
        else:
            output = np.concatenate(
                [input, np.array([[0, 0, 0, 1]], dtype=input.dtype)], axis=0)  # (4, 4)
            output[3, 3] = 1.0
    return output


def vec2skew(v):
    """
    :param v:  (3, ) torch tensor
    :return:   (3, 3)
    """
    zero = torch.zeros(1, dtype=torch.float32, device=v.device)
    skew_v0 = torch.cat([zero,    -v[2:3],   v[1:2]])  # (3, 1)
    skew_v1 = torch.cat([v[2:3],   zero,    -v[0:1]])
    skew_v2 = torch.cat([-v[1:2],   v[0:1],   zero])
    skew_v = torch.stack([skew_v0, skew_v1, skew_v2], dim=0)  # (3, 3)
    return skew_v  # (3, 3)


def Exp(r):
    """so(3) vector to SO(3) matrix
    :param r: (3, ) axis-angle, torch tensor
    :return:  (3, 3)
    """
    skew_r = vec2skew(r)  # (3, 3)
    norm_r = r.norm() + 1e-15
    eye = torch.eye(3, dtype=torch.float32, device=r.device)
    R = eye + (torch.sin(norm_r) / norm_r) * skew_r + \
        ((1 - torch.cos(norm_r)) / norm_r**2) * (skew_r @ skew_r)
    return R


def trs_decomp(A):
    if isinstance(A, torch.Tensor):
        s_vec = torch.norm(A[:3, :3], dim=0)
    else:
        s_vec = np.linalg.norm(A[:3, :3], axis=0)
    R = A[:3, :3] / s_vec
    t = A[:3, 3]
    return t, R, s_vec


class SampleObjPose(nn.Module):
    def __init__(self, pose, learn_t, learn_r, learn_s, device="cpu"):
        super(SampleObjPose, self).__init__()
        self.learn_t = torch.tensor(learn_t)
        self.learn_r = torch.tensor(learn_r)
        self.learn_s = torch.tensor(learn_s)
        self.t = nn.Parameter(torch.zeros(
            3, dtype=torch.float32, device=device))  # (N, 3)
        self.r = nn.Parameter(torch.zeros(
            3, dtype=torch.float32, device=device))  # (N, 3)
        self.s = nn.Parameter(torch.zeros(
            3, dtype=torch.float32, device=device))  # (N, 3)

        self.pose = pose
        self.i_t, self.i_R, self.i_s = trs_decomp(pose)

        if device is not None:
            self.to_gpu(device)

    def forward(self, r=None, t=None):
        s = self.s * self.learn_s + 1
        if r is not None:
            r = r * self.learn_r
        else:
            r = self.r * self.learn_r
        if t is not None:
            t = t * self.learn_t
        else:
            t = self.t * self.learn_t
        new_trs = convert3x4_4x4(torch.cat(
            [(Exp(r) @ self.i_R) * (self.i_s * s), (t + self.i_t).unsqueeze(1)], 1))

        return new_trs

    def to_gpu(self, device):
        self.learn_t = self.learn_t.to(device)
        self.learn_r = self.learn_r.to(device)
        self.learn_s = self.learn_s.to(device)


class AutoRF(LightningModule):
    def __init__(self, hparams, ap_sys: nn.Module):
        super().__init__()
        self.save_hyperparameters(hparams, ignore=["ap_sys"])
        self.ap_sys = ap_sys

        self.train_conf = hparams.train
        self.lr = self.train_conf.lr

        self.criterion = torch.nn.HuberLoss(delta=0.1)

    def configure_optimizers(self):
        optim_name = self.train_conf.get("optimizer", "adam")
        if optim_name == "adam":
            optimizer = torch.optim.Adam(
                self.ap_sys.parameters(), lr=self.lr, betas=(0, 0.90))
        elif optim_name == "sdg":
            optimizer = torch.optim.SGD(self.ap_sys.parameters(), lr=self.lr)

        return [optimizer]

    def loss(
        self, pred_rgb, pred_weight, gt_rgb, fb_masks, on_mask=False,
    ):
        loss_dict = {}
        rgb_loss = 0
        mask_loss = 0
        # rgb loss
        if on_mask:
            sel_fb_masks = (fb_masks == 0) | (fb_masks == 1)
            rgb_loss = torch.nn.MSELoss()(
                pred_rgb[sel_fb_masks], gt_rgb[sel_fb_masks]
            )
        else:
            rgb_loss = torch.nn.MSELoss()(pred_rgb, gt_rgb)
        loss_dict["rc"] = rgb_loss.item()

        # TODO: for now mask loss only on coarse
        if self.train_conf.get("weight_bg_loss", 0) > 0:
            # ensure no occupancy on bg # ensure no occupancy on bg
            bg_mask = fb_masks == 0
            bg_ratio = bg_mask.sum() / bg_mask.numel()
            if bg_mask.sum() > 0:
                bg_loss = (
                    self.train_conf.weight_bg_loss *
                    pred_weight[bg_mask].mean() * bg_ratio
                )  # l2 error to bg -> depth =0
                loss_dict["bg"] = bg_loss.item()
            else:
                bg_loss = 0.0
                loss_dict["bg"] = bg_loss

            mask_loss += bg_loss
        if self.train_conf.get("weight_fg1_loss", 0) > 0:
            # ensure fg is occupied
            fg_mask = fb_masks == 1
            fg_ratio = fg_mask.sum() / fg_mask.numel()
            if fg_mask.sum() > 0:
                fg1_loss = (
                    self.train_conf.weight_fg1_loss * fg_ratio *
                    (1 - pred_weight[fg_mask]).mean()
                )  # l2 error on sum of fg weights => 1
                loss_dict["fg1"] = fg1_loss.item()
            else:
                fg1_loss = 0.0
                loss_dict["fg1"] = fg1_loss
            mask_loss += fg1_loss

        loss = rgb_loss + mask_loss

        loss_dict["total"] = loss.item()
        return loss, loss_dict

    

    def forward_step(self, batch, num_rays, sample_pattern):
        # B V ... format
        all_images = to_device(batch["images"], self.device)
        all_fb_masks = to_device(batch["fb_masks"], self.device)
        all_enc_images = to_device(batch["enc_images"], self.device)
        all_enc_fb_masks = to_device(batch["enc_fb_masks"], self.device)
        all_W = torch.Tensor([[x.shape[2] for x in views]
                             for views in all_images]).to(self.device)
        all_H = torch.Tensor([[x.shape[1] for x in views]
                             for views in all_images]).to(self.device)

        all_poses = to_device(batch["poses"], self.device)  # (SB, NV, 4, 4)
        all_intrinsics = to_device(batch["intrinsics"], self.device)  # (SB)
        bound = batch["bound"][0]

        all_source_inds = torch.stack(
            [torch.arange(n) for n in batch["n_source"]]).to(self.device)
        b_src_images = batch_index_select(
            all_images, all_source_inds)  # SB x NS x (3,H,W)
        b_src_fb_masks = batch_index_select(all_fb_masks, all_source_inds)
        b_enc_src_images = batch_index_select(
            all_enc_images, all_source_inds)  # SB x NS x (3,H,W)
        b_enc_src_fb_masks = batch_index_select(
            all_enc_fb_masks, all_source_inds)

        b_src_H = batch_index_select(all_H, all_source_inds)
        b_src_W = batch_index_select(all_W, all_source_inds)

        b_src_intrinsics = batch_index_select(
            all_intrinsics, all_source_inds)  # (SB, NS, 3, H, W)
        b_src_poses = batch_index_select(
            all_poses, all_source_inds)  # (SB, NS, 4, 4)

        bg_color = 0

        rays_o, rays_d, inds = autorf_get_rays_v(
            b_src_poses,
            b_src_intrinsics,
            b_src_H,
            b_src_W,
            N_rays=num_rays,
            sample_pattern=sample_pattern,
            fb_masks=b_src_fb_masks,
            mask_ratio=self.train_conf.get("mask_ratio", 0.5),
        )

        s_outputs = ap_render_staged(
            self.ap_sys,
            rays_o,
            rays_d,
            staged=True,
            bg_color=bg_color,
            perturb=True,
            condition=b_enc_src_images,
            bound=bound,
            **self.train_conf,
            normalize_pts=False
        )
        C = b_src_images.shape[2]
        gt_rgb = torch.gather(rearrange(
            b_src_images, "B V C H W -> B V (H W) C"), -2, torch.stack(C * [inds], -1))
        fb_masks = torch.gather(
            rearrange(b_src_fb_masks, "B V H W -> B V (H W)"), -1, inds)  # [B, V, N]
        if C == 4:
            gt_rgb = gt_rgb[..., :3] * gt_rgb[..., 3:] + \
                bg_color * (1 - gt_rgb[..., 3:])

        gt_rgb = gt_rgb*0.5 + 0.5  # shift to 0->1 range
        pred_rgb = s_outputs["rgb"].reshape(gt_rgb.shape)
        pred_weight = s_outputs["acc_weight"]
        loss, loss_dict = self.loss(
            pred_rgb, pred_weight, gt_rgb, fb_masks, on_mask=num_rays <= 0)
        s_outputs["loss"] = loss
        s_outputs["H"] = b_src_H
        s_outputs["W"] = b_src_W
        s_outputs["inds"] = inds
        s_outputs["gt_rgb"] = gt_rgb
        s_outputs['fb_mask'] = fb_masks
        # s_outputs["mean_rgb"] = pred_rgb.mean().item()

        t_outputs = {}
        all_target_inds = torch.stack(
            [torch.arange(ns, ns + nt)
             for ns, nt in zip(batch["n_source"], batch["n_target"])]
        ).to(self.device)
        if all_target_inds.numel() > 0:
            # additional target images

            b_target_images = batch_index_select(
                all_images, all_target_inds)  # SB x NS x (3,H,W)
            b_target_fb_masks = batch_index_select(
                all_fb_masks, all_target_inds)

            b_target_H = batch_index_select(all_H, all_target_inds)
            b_target_W = batch_index_select(all_W, all_target_inds)

            b_target_intrinsics = batch_index_select(
                all_intrinsics, all_target_inds)  # (SB, NS, 3, H, W)
            b_target_poses = batch_index_select(
                all_poses, all_target_inds)  # (SB, NS, 4, 4)

            rays_o, rays_d, inds = autorf_get_rays_v(
                b_target_poses,
                b_target_intrinsics,
                b_target_H,
                b_target_W,
                N_rays=num_rays,
                sample_pattern=sample_pattern,
                fb_masks=b_target_fb_masks,  # only used if sample_pattern is not full
                mask_ratio=self.train_conf.get("mask_ratio", 0.5),
            )

            t_outputs = ap_render_staged(
                self.ap_sys,
                rays_o,
                rays_d,
                staged=True,
                bg_color=bg_color,
                perturb=False,
                condition=b_enc_src_images,
                bound=bound,
                **self.train_conf,
                normalize_pts=False
            )
            C = b_src_images.shape[2]

            gt_rgb = torch.gather(rearrange(
                b_target_images, "B V C H W -> B V (H W) C"), -2, torch.stack(C * [inds], -1))
            fb_masks = torch.gather(
                rearrange(b_target_fb_masks, "B V H W -> B V (H W)"), -1, inds)  # [B, V, N]
            if C == 4:
                gt_rgb = gt_rgb[..., :3] * gt_rgb[..., 3:] + \
                    bg_color * (1 - gt_rgb[..., 3:])

            gt_rgb = gt_rgb*0.5 + 0.5  # shift to 0->1 range
            pred_rgb = t_outputs["rgb"].reshape(gt_rgb.shape)
            pred_weight = t_outputs["acc_weight"]
            loss, loss_dict = self.loss(
                pred_rgb, pred_weight, gt_rgb, fb_masks, on_mask=num_rays <= 0)
            t_outputs["loss"] = loss
            t_outputs["H"] = b_target_H
            t_outputs["W"] = b_target_W
            t_outputs["inds"] = inds
            t_outputs["gt_rgb"] = gt_rgb
            t_outputs['fb_mask'] = fb_masks

        return s_outputs, t_outputs

    def training_step(self, batch, batch_nb):
        s_outputs, t_outputs = self.forward_step(
            batch, num_rays=self.train_conf.num_rays, sample_pattern=self.train_conf.train_pattern)
        self.log("train/loss", s_outputs['loss'].item())
        return s_outputs['loss']

    def validation_step(self, batch, batch_nb):

        s_outputs, t_outputs = self.forward_step(
            batch, num_rays=-1, sample_pattern="full")
        s_log = {}
        # restore images for metric calculation
        s_pred_rgb = restore_img(s_outputs["rgb"], int(
            s_outputs["H"][0][0]), int(s_outputs["W"][0][0]), s_outputs["inds"])
        s_gt_rgb = restore_img(s_outputs["gt_rgb"], int(
            s_outputs["H"][0][0]), int(s_outputs["W"][0][0]), s_outputs["inds"])

        s_fb_mask = restore_img(s_outputs["fb_mask"], int(
            s_outputs["H"][0][0]), int(s_outputs["W"][0][0]), s_outputs["inds"], bg=2)  # 2 is unknown

        s_log["val_loss"] = s_outputs["loss"].item()
        # ssim_val = ssim(pred_rgb, gt_rgb).item()
        s_log["val_psnr"] = psnr(s_pred_rgb, s_gt_rgb, s_fb_mask < 2).item()
        s_log['val_ssim'] = ssim(s_pred_rgb, s_gt_rgb, s_fb_mask < 2).item()

        s_log["gt_imgs"] = s_gt_rgb.cpu()  # B,V,H,W,3
        s_log["pred_imgs"] = s_pred_rgb.cpu()  # B,V,H,W,3

        t_log = {}
        if len(t_outputs) > 0:
            t_pred_rgb = restore_img(t_outputs["rgb"], int(
                t_outputs["H"][0][0]), int(t_outputs["W"][0][0]), t_outputs["inds"])
            t_gt_rgb = restore_img(t_outputs["gt_rgb"], int(
                t_outputs["H"][0][0]), int(t_outputs["W"][0][0]), t_outputs["inds"])

            t_fb_mask = restore_img(t_outputs["fb_mask"], int(
                t_outputs["H"][0][0]), int(t_outputs["W"][0][0]), t_outputs["inds"], bg=2)  # 2 is unknown

            t_log["val_loss"] = t_outputs["loss"].item()
            # ssim_val = ssim(pred_rgb, gt_rgb).item()
            t_log["val_psnr"] = psnr(t_pred_rgb, t_gt_rgb).item()
            t_log['val_ssim'] = ssim(t_pred_rgb, t_gt_rgb, t_fb_mask < 2)
            t_log["gt_imgs"] = t_gt_rgb.cpu()  # B,V,H,W,3
            t_log["pred_imgs"] = t_pred_rgb.cpu()  # B,V,H,W,3
        if False:
            # validation image for logging
            t_log["gt_imgs"] = gt_rgb.cpu()  # B,V,H,W,3
            t_log["pred_imgs"] = pred_rgb.cpu()  # B,V,H,W,3
            t_log["cam_poses"] = poses.cpu()
            t_log["intrinsics"] = intrinsics.cpu()

        log = dict(source=s_log, target=t_log)

        return log

    def validation_epoch_end(self, c_outputs):
        def log_scalars(outputs, subset="t"):
            mean_loss = np.mean([x["val_loss"] for x in outputs])
            mean_psnr = np.mean([x["val_psnr"] for x in outputs])
            mean_ssim = np.mean([x["val_ssim"] for x in outputs])

            self.log(f"val_{subset}/loss", mean_loss, sync_dist=True)
            self.log(f"val_{subset}/psnr", mean_psnr,
                     prog_bar=True, sync_dist=True)
            self.log(f"val_{subset}/ssim", mean_ssim,
                     prog_bar=False, sync_dist=True)

        # synchronize between all nodes
        if self.train_conf.get("val_on_source", True):
            s_outputs = [x["source"] for x in c_outputs]
            log_scalars(s_outputs, subset="s")

        if self.train_conf.get("val_on_target", True):
            t_outputs = [x["target"] for x in c_outputs]
            log_scalars(t_outputs, subset="t")

        # move data from all nodes
        if self.trainer.gpus > 1:
            # gather results from all processes
            all_outputs = [None for _ in range(self.trainer.gpus)]
            import torch.distributed as dist

            dist.all_gather_object(all_outputs, c_outputs)
            all_outputs = [
                output for proc_outputs in all_outputs for output in proc_outputs]
        else:
            all_outputs = c_outputs

        # evaluate on rank 0 only
        if self.global_rank == 0:
            # visualizations
            # log all validation step outputs across all processes
            all_vids = []
            for sample_idx, c_output in enumerate(all_outputs):
                if self.train_conf.get("vis_num", None) is None or sample_idx < self.train_conf.vis_num:
                    # stack gt/rgb
                    if self.train_conf.get("val_on_source", True) and self.train_conf.get("val_on_target", True):
                        # rows: source_gt/pred + target_gt/pred
                        s_V = c_output["source"]["gt_imgs"].shape[1]
                        t_V = c_output["target"]["gt_imgs"].shape[1]

                        row_ordered = flatten_along_axis(
                            [
                                c_output["source"]["gt_imgs"][0],
                                c_output["source"]["pred_imgs"][0],
                                c_output["target"]["gt_imgs"][0],
                                c_output["target"]["pred_imgs"][0],
                            ]
                        )

                        img_stack = create_img_grid(
                            row_ordered,
                            titles=["s_gt", "s_pred", "t_gt", "t_pred"],
                            rows=max(s_V, t_V),
                            cols=4,
                            text_height=0.2,
                        )
                    elif self.train_conf.get("val_on_source", True):
                     # rows: source_gt/pred + target_gt/pred
                        s_V = c_output["source"]["gt_imgs"].shape[1]
                        row_ordered = flatten_along_axis(
                            [
                                c_output["source"]["gt_imgs"][0],
                                c_output["source"]["pred_imgs"][0],
                            ]
                        )

                        img_stack = create_img_grid(
                            row_ordered,
                            titles=["s_gt", "s_pred"],
                            rows=s_V,
                            cols=2,
                            text_height=0.2,
                        )
                    else:
                        # rows: source_gt + target_gt/pred
                        s_V = c_output["source"]["gt_imgs"].shape[1]
                        t_V = c_output["target"]["gt_imgs"].shape[1]

                        row_ordered = flatten_along_axis(
                            [
                                c_output["source"]["gt_imgs"][0],
                                c_output["target"]["gt_imgs"][0],
                                c_output["target"]["pred_imgs"][0],
                            ]
                        )

                        img_stack = create_img_grid(
                            row_ordered, titles=["s_gt", "t_gt", "t_pred"], rows=max(s_V, t_V), cols=3, text_height=0.2
                        )

                    if hasattr(self.logger, "type") and self.logger.type == "wandb":
                        self.logger.log_image(
                            f"val_imgs/{sample_idx}", [img_stack])

                    elif hasattr(self.logger, "type") and self.logger.type == "tensorboard":
                        self.logger.experiment.add_images(
                            f"val_imgs/{sample_idx}", img_stack[None,].transpose(0,3,1,2), self.global_step
                        )
                    # store results locally
                    if self.hparams.run.get("result_root", None) is not None:

                        result_root = self.hparams.run.result_root
                        result_path = f"{result_root}/{self.current_epoch:03}_{sample_idx:03}"
                        imageio.imwrite(
                            f"{result_path}.png", (img_stack *
                                                   255).astype(np.uint8),
                        )

    def test_step(self, batch, batch_nb):
        test_mode = self.train_conf['test_mode']
        if test_mode == "render_novel_optim":
            self.render_novel_optim(batch, batch_nb)
        elif test_mode == "render_novel":
            self.render_novel(batch, batch_nb)
        else:
            raise NotImplementedError(f"Test mode: {test_mode} not supported")

    # novel view inference

    def render_novel_optim(self, batch, batch_nb):
        torch.set_grad_enabled(True)
        num_rays = -1
        sample_pattern = self.train_conf.get("optimize_pattern", "full")
        opt_color = self.train_conf.get("opt_color", False)
        opt_density = self.train_conf.get("opt_density", False)
        opt_pose = self.train_conf.get("opt_pose", False)
        color_latent_lr = self.train_conf.get("color_latent_lr", 0.05)
        density_latent_lr = self.train_conf.get("density_latent_lr", 0.02)
        pose_lr = self.train_conf.get("pose_lr", 0.02)
        num_optim_rounds = self.train_conf.get("num_optim_rounds", 50)

        # B V ... format
        all_images = to_device(batch["images"], self.device)
        all_fb_masks = to_device(batch["fb_masks"], self.device)
        all_enc_images = to_device(batch["enc_images"], self.device)
        all_enc_fb_masks = to_device(batch["enc_fb_masks"], self.device)
        all_W = torch.Tensor([[x.shape[2] for x in views]
                             for views in all_images]).to(self.device)
        all_H = torch.Tensor([[x.shape[1] for x in views]
                             for views in all_images]).to(self.device)

        all_poses = to_device(batch["poses"], self.device)  # (SB, NV, 4, 4)
        all_intrinsics = to_device(batch["intrinsics"], self.device)  # (SB)
        bound = batch["bound"][0]

        all_source_inds = torch.stack(
            [torch.arange(n) for n in batch["n_source"]]).to(self.device)
        b_src_images = batch_index_select(
            all_images, all_source_inds)  # SB x NS x (3,H,W)
        b_src_fb_masks = batch_index_select(all_fb_masks, all_source_inds)
        b_enc_src_images = batch_index_select(
            all_enc_images, all_source_inds)  # SB x NS x (3,H,W)
        b_enc_src_fb_masks = batch_index_select(
            all_enc_fb_masks, all_source_inds)

        b_src_H = batch_index_select(all_H, all_source_inds)
        b_src_W = batch_index_select(all_W, all_source_inds)

        b_src_intrinsics = batch_index_select(
            all_intrinsics, all_source_inds)  # (SB, NS, 3, H, W)
        b_src_poses = batch_index_select(
            all_poses, all_source_inds)  # (SB, NS, 4, 4)

        bg_color = 0

        d_cond = self.ap_sys.d_conditioner(cond=b_enc_src_images)

        # optimize latent codes
        if opt_color:
            color_latent = nn.Parameter(
                d_cond[0]['color'].detach(), requires_grad=True)
            color_latent_optimizer = torch.optim.Adam(
                [color_latent], lr=color_latent_lr)
        if opt_density:
            density_latent = nn.Parameter(
                d_cond[0]['density'].detach(), requires_grad=True)
            density_latent_optimizer = torch.optim.Adam(
                [density_latent], lr=density_latent_lr)
        if opt_pose:
            pose_model = SampleObjPose(b_src_poses[0, 0],
                                       self.train_conf.get(
                                           'learn_t', [False, False, False]),
                                       self.train_conf.get(
                                           'learn_r', [False, False, False]),
                                       self.train_conf.get(
                                           'learn_s', [False, False, False]),
                                       self.device)
            pose_optimizer = torch.optim.Adam(
                pose_model.parameters(), lr=pose_lr)

        rays_o, rays_d, inds = autorf_get_rays_v(
            b_src_poses,
            b_src_intrinsics,
            b_src_H,
            b_src_W,
            N_rays=num_rays,
            sample_pattern=sample_pattern,
            fb_masks=b_src_fb_masks,
            mask_ratio=self.train_conf.get("mask_ratio", 0.5),
        )
        for optim_round in range(num_optim_rounds):
            if opt_pose:
                # optimize pose and cast new rays
                b_src_poses = pose_model()[None, None, ...]
                rays_o, rays_d, inds = autorf_get_rays_v(
                    b_src_poses,
                    b_src_intrinsics,
                    b_src_H,
                    b_src_W,
                    N_rays=num_rays,
                    sample_pattern=sample_pattern,
                    fb_masks=b_src_fb_masks,
                    mask_ratio=self.train_conf.get("mask_ratio", 0.5),
                )

            d_cond = [{"color": color_latent, "density": density_latent}]
            s_outputs = ap_render_staged(
                self.ap_sys,
                rays_o,
                rays_d,
                staged=True,
                bg_color=bg_color,
                perturb=True,
                condition=b_enc_src_images,
                bound=bound,
                **self.train_conf,
                normalize_pts=False,
                d_cond=d_cond
            )
            C = b_src_images.shape[2]
            gt_rgb = torch.gather(rearrange(
                b_src_images, "B V C H W -> B V (H W) C"), -2, torch.stack(C * [inds], -1))
            fb_masks = torch.gather(
                rearrange(b_src_fb_masks, "B V H W -> B V (H W)"), -1, inds)  # [B, V, N]
            if C == 4:
                gt_rgb = gt_rgb[..., :3] * gt_rgb[..., 3:] + \
                    bg_color * (1 - gt_rgb[..., 3:])

            gt_rgb = gt_rgb*0.5 + 0.5  # shift to 0->1 range
            pred_rgb = s_outputs["rgb"].reshape(gt_rgb.shape)
            pred_weight = s_outputs["acc_weight"]
            loss, loss_dict = self.loss(
                pred_rgb, pred_weight, gt_rgb, fb_masks, on_mask=True)

            loss.backward()

            if opt_color:
                color_latent_optimizer.step()
                color_latent_optimizer.zero_grad()
            if opt_density:
                density_latent_optimizer.step()
                density_latent_optimizer.zero_grad()
            if opt_pose:
                pose_optimizer.step()
                pose_optimizer.zero_grad()

        # debugging
        # render views with optimized codes/poses
        all_target_inds = torch.stack(
            [torch.arange(ns, ns + nt)
             for ns, nt in zip(batch["n_source"], batch["n_target"])]
        ).to(self.device)
        # additional target images
        b_target_H = batch_index_select(all_H, all_target_inds)
        b_target_W = batch_index_select(all_W, all_target_inds)

        b_target_intrinsics = batch_index_select(
            all_intrinsics, all_target_inds)  # (SB, NS, 3, H, W)
        b_target_poses = batch_index_select(
            all_poses, all_target_inds)  # (SB, NS, 4, 4)

        with torch.no_grad():
            # source view for reference
            rays_o, rays_d, inds = autorf_get_rays_v(
                b_src_poses,
                b_src_intrinsics,
                b_src_H,
                b_src_W,
                N_rays=-1,
                sample_pattern="full",
                fb_masks=b_src_fb_masks,
                mask_ratio=self.train_conf.get("mask_ratio", 0.5),
            )
            s_outputs = ap_render_staged(
                self.ap_sys,
                rays_o,
                rays_d,
                staged=True,
                bg_color=bg_color,
                perturb=True,
                condition=b_enc_src_images,
                bound=bound,
                **self.train_conf,
                normalize_pts=False,
                d_cond=d_cond
            )
            C = b_src_images.shape[2]
            H, W = int(b_src_H[0][0]), int(b_src_W[0][0])
            s_gt_rgb = rearrange(
                b_src_images, "B V C H W -> B V H W C") * 0.5 + 0.5
            s_pred_rgb = s_outputs["rgb"].reshape(s_gt_rgb.shape)
            # target views
            rays_o, rays_d, inds = autorf_get_rays_v(
                b_target_poses,
                b_target_intrinsics,
                b_target_H,
                b_target_W,
                N_rays=-1,
                sample_pattern="full",
                mask_ratio=self.train_conf.get("mask_ratio", 0.5),
            )
            t_outputs = ap_render_staged(
                self.ap_sys,
                rays_o,
                rays_d,
                staged=True,
                bg_color=bg_color,
                perturb=True,
                condition=b_enc_src_images,
                bound=bound,
                **self.train_conf,
                normalize_pts=False,
                d_cond=d_cond
            )
            C = b_src_images.shape[2]
            H, W = int(b_target_H[0][0]), int(b_target_W[0][0])
            t_pred_rgb = rearrange(
                t_outputs["rgb"], "B V (H W) C -> B V H W C", H=H, W=W)

        # store outputs for evaluation
        inst_name = batch["path"][0].split("/")[-1]
        src_idx = batch['image_ids'][0][0]
        target_inds = batch['image_ids'][0][1:]
        store_base = self.train_conf['test_store_root']
        result_root = f"{store_base}_optim/{inst_name}/{src_idx}"
        os.makedirs(result_root, exist_ok=True)
        if batch_nb == 0:
            print(f"Storing results at: {store_base}")
        # store src gt for reference
        imageio.imwrite(f"{result_root}/src_gt.png",
                        (s_gt_rgb[0, 0].cpu().numpy() * 255).astype(np.uint8))
        imageio.imwrite(f"{result_root}/src_pred.png",
                        (s_pred_rgb[0, 0].cpu().numpy() * 255).astype(np.uint8))
        # store all target renderings
        for t_idx, target_idx in enumerate(target_inds):
            imageio.imwrite(f"{result_root}/{target_idx}_rgb.png",
                            (t_pred_rgb[0, t_idx].cpu().numpy() * 255).astype(np.uint8))

    def render_novel(self, batch, batch_nb):
        s_outputs, t_outputs = self.forward_step(
            batch, num_rays=-1, sample_pattern="full")

        # restore images for metric calculation
        s_pred_rgb = restore_img(s_outputs["rgb"], int(
            s_outputs["H"][0][0]), int(s_outputs["W"][0][0]), s_outputs["inds"])
        s_gt_rgb = restore_img(s_outputs["gt_rgb"], int(
            s_outputs["H"][0][0]), int(s_outputs["W"][0][0]), s_outputs["inds"])

        t_pred_rgb = restore_img(t_outputs["rgb"], int(
            t_outputs["H"][0][0]), int(t_outputs["W"][0][0]), t_outputs["inds"])

        # store outputs for evaluation
        inst_name = batch["path"][0].split("/")[-1]
        src_idx = batch['image_ids'][0][0]
        target_inds = batch['image_ids'][0][1:]
        store_base = self.train_conf['test_store_root']
        result_root = f"{store_base}/{inst_name}/{src_idx}"
        os.makedirs(result_root, exist_ok=True)
        if batch_nb == 0:
            print(f"Storing results at: {store_base}")
        # store src gt for reference
        imageio.imwrite(f"{result_root}/src_gt.png",
                        (s_gt_rgb[0, 0].cpu().numpy() * 255).astype(np.uint8))
        imageio.imwrite(f"{result_root}/src_pred.png",
                        (s_pred_rgb[0, 0].cpu().numpy() * 255).astype(np.uint8))
        # store all target renderings
        for t_idx, target_idx in enumerate(target_inds):
            imageio.imwrite(f"{result_root}/{target_idx}_rgb.png",
                            (t_pred_rgb[0, t_idx].cpu().numpy() * 255).astype(np.uint8))

    # <----

    # frame-based visualization --_>

    def on_predict_start(self) -> None:
        # create a container for all render entities produces in test_step
        self.render_entitites = []

    def predict_step(self, batch, batch_nb):
        render_entity = self.infer_render_entity(batch, batch_nb)
        self.render_entitites.append(render_entity)

    def infer_render_entity(self, batch, batch_nb):
        # B V ... format
        all_images = to_device(batch["images"], self.device)
        all_fb_masks = to_device(batch["fb_masks"], self.device)
        all_enc_images = to_device(batch["enc_images"], self.device)
        all_enc_fb_masks = to_device(batch["enc_fb_masks"], self.device)
        all_W = torch.Tensor([[x.shape[2] for x in views]
                             for views in all_images]).to(self.device)
        all_H = torch.Tensor([[x.shape[1] for x in views]
                             for views in all_images]).to(self.device)

        all_poses = to_device(batch["poses"], self.device)  # (SB, NV, 4, 4)
        all_intrinsics = to_device(batch["intrinsics"], self.device)  # (SB)

        all_source_inds = torch.stack(
            [torch.arange(n) for n in batch["n_source"]]).to(self.device)
        b_enc_src_images = batch_index_select(
            all_enc_images, all_source_inds)  # SB x NS x (3,H,W)

        b_src_intrinsics = batch_index_select(
            all_intrinsics, all_source_inds)  # (SB, NS, 3, H, W)
        b_src_poses = batch_index_select(
            all_poses, all_source_inds)  # (SB, NS, 4, 4)

        d_cond = self.ap_sys.d_conditioner(cond=b_enc_src_images)

        render_entity = {
            "inst_token": batch['inst_token'][0],
            "frame_token": batch['inst_token'][0].split('_')[0],
            "color_code": d_cond[0]['color'],
            "density_code": d_cond[0]['density'],
            "cam2can": b_src_poses[0, 0],
            "intrinsics": b_src_intrinsics[0, 0],
            "intrinsics_org": b_src_intrinsics[0, 0],
            "cam_K_org": batch["cam_K_org"][0],
        }

        return render_entity

    def on_predict_end(self) -> None:
        from visualize_helper import full_render_entities_framewise, store_renderings_framewise, create_gif
        import pickle

        base_factor = self.train_conf.get("base_factor", 0.5)
        base_H, base_W = self.train_conf.get(
            "base_H", 900), self.train_conf.get("base_W", 1600)
        base_H, base_W = int(base_factor*base_H), int(base_factor * base_W)

        # aggregate  by frame
        frame_render_entities = defaultdict(list)
        for render_entity in self.render_entitites:
            frame_token = render_entity['frame_token']
            frame_render_entities[frame_token].append(render_entity)

        camera_track_root = os.path.expanduser(
            self.train_conf['camera_track_root'])
        overlay_mode = self.train_conf["overlay_mode"]
        store_root = os.path.expanduser(self.train_conf['vis_store_root'])
        print(f"Storing track renderings at: {store_root}")
        for frame_token, render_entities in frame_render_entities.items():
            print(f"Creating track rendering for: {frame_token}")
            # load camera track
            camera_track = pickle.load(
                open(f"{camera_track_root}/{frame_token}.pkl", 'rb'))
            org_K = render_entities[0]['cam_K_org'].cpu().numpy()[0]
            for track_idx in range(len(camera_track)):
                overlayed_imgs, track_inst_imgs = full_render_entities_framewise(self, track_idx, render_entities=render_entities, camera_track=camera_track,
                                                                                base_H=base_H, base_W=base_W, base_factor=base_factor,
                                                                                grid_out_path=None,
                                                                                overlay_mode=overlay_mode,
                                                                                org_K=org_K)
                store_renderings_framewise(
                    store_root, frame_token, track_idx, overlayed_imgs, track_inst_imgs)
            create_gif(f"{store_root}/{frame_token}/overlays")
    # <----
    def full_render(self, color_latent,density_latent,H, W,intrinsics,pose, bg_color=0, bound=0.5, alpha_th=None):
        with torch.no_grad():
            rays_o, rays_d, inds = autorf_get_rays_v(
                pose[None,None,...],
                intrinsics[None,None,...],
                torch.Tensor([[H]]),
                torch.Tensor([[W]]),
                N_rays=-1,
                sample_pattern="full",
                mask_ratio=self.train_conf.get("mask_ratio", 0.5),
            )
            d_cond = [{"color": color_latent, "density": density_latent}]
            outputs = ap_render_staged(
                self.ap_sys,
                rays_o,
                rays_d,
                staged=True,
                bg_color=bg_color,
                perturb=True,
                bound=bound,
                **self.train_conf,
                normalize_pts=False,
                d_cond=d_cond
            )
            pred_rgb = rearrange(
                outputs['rgb'], "B V (H W) C-> B V H W C", H=H, W=W)
            pred_alpha = rearrange(
                outputs['acc_weight'], "B V (H W)-> B V H W", H=H, W=W)

            if alpha_th is not None:
                # sharp transition at alpha threshold
                pred_alpha = np.clip(1 / (1 + np.exp(-(pred_alpha - alpha_th) * 50)), 0, 1)

            pred_img = torch.cat([pred_rgb, pred_alpha[...,None]],-1)
 
            
        return pred_img[0,0].cpu().numpy()