from pathlib import Path
import numpy as np
from tqdm import tqdm
import pickle
import pandas as pd
from glob import glob
from PIL import Image
import torch
from lpips import LPIPS
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
import os
import argparse


def evaluate_novel_views(novel_rend_root, data_root, res=(64,64)):
    lpips_vgg = LPIPS(net="vgg").cuda()
    novel_eval_results = []
    for inst_novel_root in tqdm(Path(novel_rend_root).iterdir()):
        if not inst_novel_root.is_dir():
            continue
        inst_fn = inst_novel_root.stem
        for inst_src_root in Path(inst_novel_root).iterdir():
            src_idx = inst_src_root.stem

            for target_rgb_fn in glob(f"{str(inst_src_root)}/*_rgb.png"):
                target_idx = target_rgb_fn.split("/")[-1].split("_")[0]
                
                eval_results = {"inst_fn": inst_fn, "src_idx": src_idx, "target_idx": target_idx}
                if os.path.exists(target_rgb_fn[:-4] + "a.png"):
                    target_pred_rgb = np.array(Image.open(target_rgb_fn[:-4] + "a.png"))
                else:
                    target_pred_rgb = np.array(Image.open(target_rgb_fn))

                target_gt_rgb = Image.open(f"{data_root}/{inst_fn}/rgb_masked/{target_idx}.jpg")
                target_fb_mask = Image.open(f"{data_root}/{inst_fn}/fb_mask/{target_idx}.png")
                target_gt_rgb = np.array(target_gt_rgb.resize((res,res)))
                target_fb_mask = np.array(target_fb_mask.resize((res,res), Image.NEAREST))
                # mask out unknown area
                target_unknown_area = target_fb_mask == 2
                target_gt_rgb[target_unknown_area] = 0
                target_pred_rgb[target_unknown_area] = 0

                if target_pred_rgb.shape[-1] == 4:
                    target_pred_rgb[target_pred_rgb[..., 3] == 0] = 0
                    target_pred_rgb = target_pred_rgb[..., :3]

                # compute metrics
                psnr = peak_signal_noise_ratio(target_gt_rgb, target_pred_rgb, data_range=255)
                ssim = structural_similarity(target_gt_rgb, target_pred_rgb, multichannel=True, data_range=255,)
                lpips = lpips_vgg(
                    torch.from_numpy(target_gt_rgb).permute(2, 0, 1).cuda(),
                    torch.from_numpy(target_pred_rgb).permute(2, 0, 1).cuda(),
                ).item()
                eval_results.update(
                    {
                        "psnr": psnr,
                        "ssim": ssim,
                        "lpips": lpips,
                    }
                )
                novel_eval_results.append(eval_results)

    eval_results_df = pd.DataFrame.from_dict(novel_eval_results)
    print(eval_results_df[["psnr", "ssim","lpips"]].mean())
    eval_results_df.to_pickle(f"{novel_rend_root}/eval_results_df_val.pkl")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--rend_root", type=str, help="path to novel view renderings")
    parser.add_argument("--data_root", type=str, help="path to dataset root")
    parser.add_argument("--res", type=int, default=64, help="resolution used to calculate metrics")
    args = parser.parse_args()

    evaluate_novel_views(args.rend_root, args.data_root, args.res)  




