import torch
from torch.nn import functional as F
from kornia import create_meshgrid
import random
import os
import numpy as np
import warnings
from dutils import dot
import hashlib


def seed_everything(seed):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    # torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.benchmark = True


def lift(x, y, z, intrinsics):
    # x, y, z: [B, N]
    # intrinsics: [B, 3, 3]

    fx = intrinsics[..., 0, 0].unsqueeze(-1)
    fy = intrinsics[..., 1, 1].unsqueeze(-1)
    cx = intrinsics[..., 0, 2].unsqueeze(-1)
    cy = intrinsics[..., 1, 2].unsqueeze(-1)
    sk = intrinsics[..., 0, 1].unsqueeze(-1)

    x_lift = (x - cx + cy * sk / fy - sk * y / fy) / fx * z
    y_lift = (y - cy) / fy * z

    # homogeneous
    return torch.stack((x_lift, y_lift, z, torch.ones_like(z)), dim=-1)


def autorf_get_rays(c2w, intrinsics, H, W, N_rays=-1, sample_pattern="random", fb_masks=None, mask_ratio=0.5):
    # c2w: [B, 4, 4]
    # intrinsics: [B, 3, 3]
    # return: rays_o, rays_d: [B, N_rays, 3]
    # return: select_inds: [B, N_rays]

    device = c2w.device
    rays_o = c2w[..., :3, 3]  # [B, 3]
    prefix = c2w.shape[:-2]

    strided_selection = "stride" in sample_pattern

    if torch.all(H[0]==H) and torch.all(W[0]==W):
        H, W = int(H[0]), int(W[0]) 
    else:
        raise NotImplementedError("different resolutions not yet supported")
    if N_rays <= 0 or fb_masks is None or strided_selection:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            grid = create_meshgrid(H,W, normalized_coordinates=False, device=device)[0]
        # same height/width, expand common indices
        i, j = (
            grid[..., 0].reshape(-1).expand([*prefix, H * W]).long(),
            grid[..., 1].reshape(-1).expand([*prefix, H * W]).long(),
        )


    if N_rays > 0 and not strided_selection:
        N_rays = min(N_rays, H * W)
        if fb_masks is not None:
            select_inds = []
            for b in range(fb_masks.shape[0]):
                b_fg_inds = torch.nonzero(fb_masks[b] == 1)
                b_bg_inds = torch.nonzero(fb_masks[b] == 0)
                N_fg = int(N_rays * mask_ratio)
                N_bg = N_rays - N_fg
                b_fg_inds = b_fg_inds[torch.randperm(b_fg_inds.shape[0])[:N_fg]]
                b_bg_inds = b_bg_inds[torch.randperm(b_bg_inds.shape[0])[:N_bg]]
                b_inds = torch.cat([b_fg_inds, b_bg_inds], 0)
                if len(b_inds) < N_rays:
                    b_inds = torch.cat(
                        [
                            b_inds,
                            torch.tensor(random.choices(b_inds.tolist(), k=N_rays - len(b_inds)), device=b_inds.device),
                        ]
                    )
                select_inds.append(b_inds)
            select_inds = torch.stack(select_inds, 0)
            j, i = select_inds[..., 0], select_inds[..., 1]
        else:
            select_hs = torch.randint(0, H, size=[N_rays], device=device)
            select_ws = torch.randint(0, W, size=[N_rays], device=device)
            select_inds = select_hs * W + select_ws
            select_inds = select_inds.expand([*prefix, N_rays])
            i = torch.gather(i, -1, select_inds)
            j = torch.gather(j, -1, select_inds)
    if strided_selection:
        stride = int(sample_pattern.split("_")[-1])  # stride_X
        i = i[..., ::stride]
        j = (torch.div(j,stride, rounding_mode="floor")*stride)[...,::stride]

    select_inds = j * W + i

    pixel_points_cam = lift(i, j, torch.ones_like(i), intrinsics=intrinsics)
    pixel_points_cam = pixel_points_cam.transpose(-1, -2)

    world_coords = torch.bmm(c2w, pixel_points_cam).transpose(-1, -2)[..., :3]

    rays_d = world_coords - rays_o[..., None, :]
    rays_d = F.normalize(rays_d, dim=-1)

    rays_o = rays_o[..., None, :].expand_as(rays_d)

    return rays_o, rays_d, select_inds


def autorf_get_rays_v(c2w, intrinsics, H, W, N_rays=-1, sample_pattern="random", fb_masks=None, mask_ratio=0.5):
    rays_o = []
    rays_d = []
    select_inds = []

    for v in range(c2w.shape[1]):
        v_rays_o, v_rays_d, v_select_inds = autorf_get_rays(
            c2w[:, v],
            intrinsics[:, v],
            H[:,v],
            W[:,v],
            N_rays,
            sample_pattern=sample_pattern,
            fb_masks=fb_masks[:, v] if fb_masks is not None else None,
            mask_ratio=mask_ratio,
        )
        rays_o.append(v_rays_o)
        rays_d.append(v_rays_d)
        select_inds.append(v_select_inds)
    return torch.stack(rays_o, 1), torch.stack(rays_d, 1), torch.stack(select_inds, 1)


def unproject_2d_3d_range(cam2world, K, d, uv=None):
    if uv is None and len(d.shape) >= 2:
        # create mesh grid according to d
        uv = np.stack(np.meshgrid(np.arange(d.shape[1]), np.arange(d.shape[0])), -1)
        uv = uv.reshape(-1, 2)
        d = d.reshape(-1)
    if isinstance(uv, np.ndarray):
        uvh = np.concatenate([uv, np.ones((len(uv), 1))], -1)
        cam_point = uv[0] * d / np.sqrt(1 / K[0, 0] ** 2 + uv[0] ** 2)
    else:
        uvh = torch.cat([uv, torch.ones(len(uv), 1).to(uv)], -1)
        cam_point = dot(torch.inverse(K), uvh) * d[:, None]

    world_point = dot(cam2world, cam_point)
    return world_point


def project_3d_2d(cam2world, K, world_point, with_dist=False, discrete=True, round=True):
    from dutils import dot

    if isinstance(world_point, np.ndarray):
        cam_point = dot(np.linalg.inv(cam2world), world_point)
        point_dist = np.sqrt((cam_point ** 2).sum(-1))
        img_point = dot(K, cam_point)
        uv_point = img_point[:, :2] / img_point[:, 2][:, None]
        if discrete:
            if round:
                uv_point = np.round(uv_point)
            uv_point = uv_point.astype(np.int)
        if with_dist:
            return uv_point, img_point[:, 2], point_dist
        return uv_point
    else:
        cam_point = dot(torch.inverse(cam2world), world_point)
        point_dist = (cam_point ** 2).sum(-1).sqrt()
        img_point = dot(K, cam_point)
        uv_point = img_point[:, :2] / img_point[:, 2][:, None]
        if discrete:
            if round:
                uv_point = torch.round(uv_point)
                uv_point = uv_point.int()
        if with_dist:
            return uv_point, img_point[:, 2], point_dist

        return uv_point


def int_hash(x):
    return int(hashlib.sha1(x.encode("utf-8")).hexdigest(), 16) % (10 ** 8)


def dist2depth(K, dist, uv=None):
    if uv is None and len(dist.shape) >= 2:
        # create mesh grid according to d
        uv = np.stack(np.meshgrid(np.arange(dist.shape[1]), np.arange(dist.shape[0])), -1)
        uv = uv.reshape(-1, 2)
        dist = dist.reshape(-1)
        if not isinstance(dist, np.ndarray):
            uv = torch.from_numpy(uv).to(dist)
    if isinstance(dist, np.ndarray):
        # z * np.sqrt(x_temp**2+y_temp**2+z_temp**2) = dist
        uvh = np.concatenate([uv, np.ones((len(uv), 1))], -1)
        temp_point = dot(np.linalg.inv(K), uvh)
        z = dist / np.linalg.norm(temp_point, axis=1)

    else:
        uvh = torch.cat([uv, torch.ones(len(uv), 1).to(uv)], -1)
        temp_point = dot(torch.inverse(K), uvh)
        z = dist / torch.linalg.norm(temp_point, dim=1)
    return z


def depth2dist(K, depth, uv=None):
    if uv is None and len(depth.shape) >= 2:
        # create mesh grid according to d
        uv = np.stack(np.meshgrid(np.arange(depth.shape[1]), np.arange(depth.shape[0])), -1)
        uv = uv.reshape(-1, 2)
        depth = depth.reshape(-1)
        if not isinstance(depth, np.ndarray):
            uv = torch.from_numpy(uv).to(depth)
    if isinstance(depth, np.ndarray):
        # z * np.sqrt(x_temp**2+y_temp**2+z_temp**2) =depth
        uvh = np.concatenate([uv, np.ones((len(uv), 1))], -1)
        temp_point = dot(np.linalg.inv(K), uvh)
        dist = depth * np.linalg.norm(temp_point, axis=1)

    else:
        uvh = torch.cat([uv, torch.ones(len(uv), 1).to(uv)], -1)
        temp_point = dot(torch.inverse(K), uvh)
        dist = depth * torch.linalg.norm(temp_point, dim=1)
    return dist


def get_num_parameters(model):
    lvl0_stats = dict(total=np.array([0, 0]))
    for name, var in model.named_parameters():
        lvl0_name = name.split(".")[0]
        para_count = np.array([var.numel(), var.numel() if var.requires_grad else 0])
        lvl0_stats["total"] = lvl0_stats["total"] + para_count
        lvl0_stats[lvl0_name] = lvl0_stats.get(lvl0_name, np.array([0, 0])) + para_count
    return lvl0_stats
